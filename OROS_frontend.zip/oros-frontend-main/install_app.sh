#!/bin/bash
echo "========================================================="
echo "  INSTALLING OROS APP - LOGIN SCREEN FIXED"
echo "========================================================="
echo ""

echo "[1/3] Uninstalling old version..."
adb uninstall com.example.oros
echo ""

echo "[2/3] Installing new version..."
adb install app/build/outputs/apk/debug/app-debug.apk
echo ""

echo "[3/3] Launching app..."
adb shell am start -n com.example.oros/.LoginActivity
echo ""

echo "========================================================="
echo "  DONE! LOGIN SCREEN SHOULD NOW APPEAR!"
echo "========================================================="
echo ""
echo "The app will now show the login screen every time."
echo "Long-press the Login button to skip login for testing."
echo ""
