package com.oros.medical.data.models

data class EntityItem(
    val text: String,
    val type: String? = null
)