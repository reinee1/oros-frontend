package com.oros.medical.data.models

data class EntitiesResponse(
    val symptoms: List<String>,
    val medications: List<String>,
    val procedures: List<String>,
    val lab_values: List<String>
)
