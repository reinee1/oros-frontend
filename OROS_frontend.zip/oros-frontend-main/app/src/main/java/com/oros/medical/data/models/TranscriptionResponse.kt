package com.oros.medical.data.models

data class TranscriptionResponse(
    val id: Int,
    val text: String? = null
)
