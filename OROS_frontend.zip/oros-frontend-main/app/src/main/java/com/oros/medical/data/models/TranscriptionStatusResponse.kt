package com.oros.medical.data.models

data class TranscriptionStatusResponse(
    val status: String,
    val message: String? = null
)
