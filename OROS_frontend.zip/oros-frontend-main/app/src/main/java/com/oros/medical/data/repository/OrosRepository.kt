package com.oros.medical.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.oros.medical.data.models.*
import com.oros.medical.data.network.OrosRetrofitClient
import com.oros.medical.utils.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

/**
 * Repository class for OROS API operations
 * Handles all API calls and provides a clean interface for the UI/ViewModel layer
 */
class OrosRepository(private val context: Context) {

    private val api by lazy { OrosRetrofitClient.getApiService() }
    private val prefs: SharedPreferences by lazy {
        context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
    }

    // ==================== AUTHENTICATION ====================

    suspend fun login(email: String, password: String): Result<TokenResponse> = withContext(Dispatchers.IO) {
        try {
            val response = api.login(email, password)
            if (response.isSuccessful && response.body() != null) {
                val tokenResponse = response.body()!!
                // Save token to SharedPreferences
                prefs.edit()
                    .putString(Constants.KEY_AUTH_TOKEN, tokenResponse.accessToken)
                    .apply()
                Result.success(tokenResponse)
            } else {
                Result.failure(Exception("Login failed: ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getCurrentDoctor(): Result<DoctorMe> = safeApiCall {
        api.getCurrentDoctor()
    }

    fun logout() {
        prefs.edit()
            .remove(Constants.KEY_AUTH_TOKEN)
            .remove(Constants.KEY_DOCTOR_ID)
            .apply()
    }

    fun isLoggedIn(): Boolean {
        return prefs.getString(Constants.KEY_AUTH_TOKEN, null) != null
    }

    // ==================== DOCTORS ====================

    suspend fun createDoctor(doctor: DoctorCreate): Result<Doctor> = safeApiCall {
        api.createDoctor(doctor)
    }

    suspend fun listDoctors(
        limit: Int = 20,
        offset: Int = 0,
        search: String? = null
    ): Result<List<Doctor>> = safeApiCall {
        api.listDoctors(limit, offset, search)
    }

    suspend fun getDoctor(doctorId: Int): Result<Doctor> = safeApiCall {
        api.getDoctor(doctorId)
    }

    suspend fun updateDoctor(doctorId: Int, update: DoctorUpdate): Result<Doctor> = safeApiCall {
        api.updateDoctor(doctorId, update)
    }

    suspend fun deleteDoctor(doctorId: Int): Result<Unit> = safeApiCall {
        api.deleteDoctor(doctorId)
    }

    // ==================== PATIENTS ====================

    suspend fun createPatient(patient: PatientCreate): Result<Patient> = safeApiCall {
        api.createPatient(patient)
    }

    suspend fun listPatients(
        limit: Int = 20,
        offset: Int = 0,
        search: String? = null
    ): Result<List<Patient>> = safeApiCall {
        api.listPatients(limit, offset, search)
    }

    suspend fun listMyPatients(): Result<List<Patient>> = safeApiCall {
        api.listMyPatients()
    }

    suspend fun getPatient(patientId: Int): Result<PatientDetail> = safeApiCall {
        api.getPatient(patientId)
    }

    suspend fun updatePatient(patientId: Int, update: PatientUpdate): Result<Patient> = safeApiCall {
        api.updatePatient(patientId, update)
    }

    suspend fun deletePatient(patientId: Int): Result<Unit> = safeApiCall {
        api.deletePatient(patientId)
    }

    // ==================== NOTES ====================

    suspend fun createNote(note: NoteCreate): Result<Note> = safeApiCall {
        api.createNote(note)
    }

    suspend fun listNotes(
        limit: Int = 20,
        offset: Int = 0,
        patientId: Int? = null,
        doctorId: Int? = null,
        surgeryId: Int? = null,
        hasTranscription: Boolean? = null,
        search: String? = null
    ): Result<List<Note>> = safeApiCall {
        api.listNotes(limit, offset, patientId, doctorId, surgeryId, hasTranscription, search)
    }

    suspend fun getNote(noteId: Int): Result<Note> = safeApiCall {
        api.getNote(noteId)
    }

    suspend fun updateNote(noteId: Int, update: NoteUpdate): Result<Note> = safeApiCall {
        api.updateNote(noteId, update)
    }

    suspend fun deleteNote(noteId: Int): Result<Unit> = safeApiCall {
        api.deleteNote(noteId)
    }

    // ==================== TRANSCRIPTIONS ====================

    suspend fun createTranscription(transcription: TranscriptionCreate): Result<Transcription> = safeApiCall {
        api.createTranscription(transcription)
    }

    suspend fun listTranscriptions(
        limit: Int = 20,
        offset: Int = 0,
        doctorId: Int? = null,
        patientId: Int? = null,
        status: TranscriptionStatus? = null,
        language: String? = null,
        completedFrom: String? = null,
        completedTo: String? = null,
        search: String? = null
    ): Result<List<Transcription>> = safeApiCall {
        api.listTranscriptions(limit, offset, doctorId, patientId, status, language, completedFrom, completedTo, search)
    }

    suspend fun getTranscription(transcriptionId: Int): Result<Transcription> = safeApiCall {
        api.getTranscription(transcriptionId)
    }

    suspend fun updateTranscription(transcriptionId: Int, update: TranscriptionUpdateModel): Result<Transcription> = safeApiCall {
        api.updateTranscription(transcriptionId, update)
    }

    suspend fun deleteTranscription(transcriptionId: Int): Result<Unit> = safeApiCall {
        api.deleteTranscription(transcriptionId)
    }

    // ==================== SURGERIES ====================

    suspend fun createSurgery(surgery: SurgeryCreate): Result<Surgery> = safeApiCall {
        api.createSurgery(surgery)
    }

    suspend fun listSurgeries(
        limit: Int = 20,
        offset: Int = 0,
        patientId: Int? = null,
        doctorId: Int? = null,
        operatingRoomId: Int? = null,
        status: SurgeryStatus? = null,
        dateFrom: String? = null,
        dateTo: String? = null,
        search: String? = null
    ): Result<List<Surgery>> = safeApiCall {
        api.listSurgeries(limit, offset, patientId, doctorId, operatingRoomId, status, dateFrom, dateTo, search)
    }

    suspend fun getSurgery(surgeryId: Int): Result<Surgery> = safeApiCall {
        api.getSurgery(surgeryId)
    }

    suspend fun updateSurgery(surgeryId: Int, update: SurgeryUpdate): Result<Surgery> = safeApiCall {
        api.updateSurgery(surgeryId, update)
    }

    suspend fun deleteSurgery(surgeryId: Int): Result<Unit> = safeApiCall {
        api.deleteSurgery(surgeryId)
    }

    // ==================== OPERATING ROOMS ====================

    suspend fun createOperatingRoom(room: OperatingRoomCreate): Result<OperatingRoom> = safeApiCall {
        api.createOperatingRoom(room)
    }

    suspend fun listOperatingRooms(
        limit: Int = 20,
        offset: Int = 0,
        status: RoomStatus? = null,
        capacityMin: Int? = null,
        capacityMax: Int? = null,
        search: String? = null
    ): Result<List<OperatingRoom>> = safeApiCall {
        api.listOperatingRooms(limit, offset, status, capacityMin, capacityMax, search)
    }

    suspend fun getOperatingRoom(roomId: Int): Result<OperatingRoom> = safeApiCall {
        api.getOperatingRoom(roomId)
    }

    suspend fun updateOperatingRoom(roomId: Int, update: OperatingRoomUpdate): Result<OperatingRoom> = safeApiCall {
        api.updateOperatingRoom(roomId, update)
    }

    suspend fun deleteOperatingRoom(roomId: Int): Result<Unit> = safeApiCall {
        api.deleteOperatingRoom(roomId)
    }

    // ==================== NOTIFICATIONS ====================

    suspend fun createNotification(notification: NotificationCreate): Result<Notification> = safeApiCall {
        api.createNotification(notification)
    }

    suspend fun listNotifications(
        limit: Int = 20,
        offset: Int = 0,
        doctorId: Int? = null,
        isRead: Boolean? = null,
        priority: Priority? = null,
        relatedEntityType: String? = null,
        createdFrom: String? = null,
        createdTo: String? = null,
        search: String? = null
    ): Result<List<Notification>> = safeApiCall {
        api.listNotifications(limit, offset, doctorId, isRead, priority, relatedEntityType, createdFrom, createdTo, search)
    }

    suspend fun getNotification(notificationId: Int): Result<Notification> = safeApiCall {
        api.getNotification(notificationId)
    }

    suspend fun updateNotification(notificationId: Int, update: NotificationUpdate): Result<Notification> = safeApiCall {
        api.updateNotification(notificationId, update)
    }

    suspend fun deleteNotification(notificationId: Int): Result<Unit> = safeApiCall {
        api.deleteNotification(notificationId)
    }

    suspend fun markNotificationRead(notificationId: Int): Result<Notification> = safeApiCall {
        api.markNotificationRead(notificationId)
    }

    // ==================== HELPER FUNCTIONS ====================

    private suspend fun <T> safeApiCall(
        apiCall: suspend () -> Response<T>
    ): Result<T> = withContext(Dispatchers.IO) {
        try {
            val response = apiCall()
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                val errorMessage = response.errorBody()?.string() ?: response.message()
                Result.failure(Exception("API Error: $errorMessage"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
