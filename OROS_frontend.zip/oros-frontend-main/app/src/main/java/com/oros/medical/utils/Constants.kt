package com.oros.medical.utils

/**
 * Application-wide constants
 */
object Constants {


    // ===================== API CONFIG =====================

    // IMPORTANT: Set your computer's IP address here!
    // To find your IP: Open Command Prompt and type: ipconfig
    // Look for "IPv4 Address" (something like 192.168.x.x)

    private const val PHYSICAL_DEVICE_IP = "10.169.9.90"  // Your WiFi IP
    private const val EMULATOR_IP = "10.0.2.2"               // Emulator special IP

    // Auto-detect emulator vs physical device
    private val isEmulator: Boolean
        get() = (android.os.Build.FINGERPRINT.startsWith("generic")
                || android.os.Build.FINGERPRINT.startsWith("unknown")
                || android.os.Build.MODEL.contains("google_sdk")
                || android.os.Build.MODEL.contains("Emulator")
                || android.os.Build.MODEL.contains("Android SDK built for x86")
                || android.os.Build.MANUFACTURER.contains("Genymotion")
                || android.os.Build.BRAND.startsWith("generic") && android.os.Build.DEVICE.startsWith("generic")
                || "google_sdk" == android.os.Build.PRODUCT)

    private val SERVER_IP: String
        get() = if (isEmulator) EMULATOR_IP else PHYSICAL_DEVICE_IP

    // TEMPORARY FIX:
    // Try #1: Standard emulator address
    val BASE_URL: String
        get() = "http://10.0.2.2:8000/"

    // If above doesn't work, uncomment this and use Mac's IP:
    // val BASE_URL: String
    //     get() = "http://192.168.10.163:8000/"

    // Original dynamic version (commented out for testing):
    // val BASE_URL: String
    //     get() = "http://$SERVER_IP:8000/"

    // Alternative configurations:
    // const val BASE_URL = "http://10.0.2.2:8000/"         // For Android Emulator only
    // const val BASE_URL = "https://your-server.com/"      // For production

    val WS_BASE_URL: String
        get() = "ws://$SERVER_IP:8000/"

    // API Endpoints (paths are relative to BASE_URL)
    // Authentication
    const val ENDPOINT_LOGIN = "auth/login"
    const val ENDPOINT_ME = "auth/me"

    // Doctors
    const val ENDPOINT_DOCTORS = "doctors"

    // Patients
    const val ENDPOINT_PATIENTS = "patients"
    const val ENDPOINT_MY_PATIENTS = "patients/my"

    // Notes
    const val ENDPOINT_NOTES = "notes"

    // Transcriptions
    const val ENDPOINT_TRANSCRIPTIONS = "transcriptions"

    // Surgeries
    const val ENDPOINT_SURGERIES = "surgeries"

    // Operating Rooms
    const val ENDPOINT_OPERATING_ROOMS = "operating-rooms"

    // Notifications
    const val ENDPOINT_NOTIFICATIONS = "notifications"

    // WebSocket Endpoints
    const val WS_TRANSCRIBE = "ws/transcribe/{id}"


    // ===================== AUDIO RECORDING =====================

    // Whisper-compatible audio settings
    const val SAMPLE_RATE = 16000                         // 16 kHz
    const val CHANNEL_CONFIG = android.media.AudioFormat.CHANNEL_IN_MONO
    const val AUDIO_FORMAT = android.media.AudioFormat.ENCODING_PCM_16BIT

    // Audio streaming
    const val CHUNK_SIZE = 1024
    const val CHUNK_DURATION_MS = 1000                    // Send chunk every 1 second

    // Audio file
    const val AUDIO_FILE_EXTENSION = ".wav"
    const val AUDIO_MIME_TYPE = "audio/wav"


    // ===================== SOCKET MESSAGE TYPES =====================

    const val MSG_TYPE_AUDIO_CHUNK = "audio_chunk"
    const val MSG_TYPE_TRANSCRIPTION_UPDATE = "transcription_update"
    const val MSG_TYPE_ANALYSIS_COMPLETE = "analysis_complete"
    const val MSG_TYPE_STATUS = "status"
    const val MSG_TYPE_COMPLETE = "complete"
    const val MSG_TYPE_ERROR = "error"
    const val MSG_TYPE_CANCEL = "cancel"


    // ===================== SHARED PREFS =====================

    const val PREFS_NAME = "OROSPrefs"
    const val KEY_DOCTOR_ID = "doctor_id"
    const val KEY_AUTH_TOKEN = "auth_token"


    // ===================== PERMISSIONS =====================

    const val REQUEST_RECORD_AUDIO_PERMISSION = 200
    const val REQUEST_WRITE_EXTERNAL_STORAGE = 201


    // ===================== NETWORK & UI =====================

    const val NETWORK_TIMEOUT = 30L                       // seconds
    const val WEBSOCKET_RECONNECT_DELAY = 3000L           // ms

    const val ANIMATION_DURATION = 300L
    const val DEBOUNCE_DELAY = 500L
}
