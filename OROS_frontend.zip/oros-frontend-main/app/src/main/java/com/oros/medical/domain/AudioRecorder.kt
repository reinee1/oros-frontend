package com.oros.medical.domain

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class AudioRecorder {

    private val TAG = "AudioRecorder"

    private var audioRecord: AudioRecord? = null
    private var isRecording = false
    private var recordingJob: Job? = null

    private val bufferSize: Int
    private var outputFile: File? = null
    private var outputStream: FileOutputStream? = null

    private val _audioChunks = MutableSharedFlow<ByteArray>(
        replay = 0,
        extraBufferCapacity = 10,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val audioChunks: SharedFlow<ByteArray> = _audioChunks.asSharedFlow()

    private val _recordingStatus = MutableSharedFlow<RecordingStatus>()
    val recordingStatus: SharedFlow<RecordingStatus> = _recordingStatus.asSharedFlow()

    init {
        bufferSize = AudioRecord.getMinBufferSize(
            16000,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(2048)
    }

    fun startRecording(file: File): Boolean {
        if (isRecording) return false

        return try {
            outputFile = file
            outputStream = FileOutputStream(file)

            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "Failed to initialize AudioRecord")
                return false
            }

            audioRecord?.startRecording()
            isRecording = true

            recordingJob = CoroutineScope(Dispatchers.IO).launch {
                recordLoop()
            }

            _recordingStatus.tryEmit(RecordingStatus.Started)
            true

        } catch (e: Exception) {
            Log.e(TAG, "Error starting recording", e)
            false
        }
    }

    private suspend fun recordLoop() {
        val buffer = ByteArray(bufferSize)
        var totalBytes = 0L

        try {
            while (isRecording) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (read > 0) {
                    outputStream?.write(buffer, 0, read)
                    totalBytes += read
                    _audioChunks.tryEmit(buffer.copyOf(read))

                    val seconds = totalBytes / (16000 * 2)
                    _recordingStatus.tryEmit(RecordingStatus.Recording(seconds.toInt()))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in record loop", e)
            _recordingStatus.tryEmit(RecordingStatus.Error(e.message ?: "Unknown"))
        }
    }

    fun stopRecording(): File? {
        if (!isRecording) return null

        isRecording = false
        recordingJob?.cancel()

        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null

            outputStream?.close()

            _recordingStatus.tryEmit(RecordingStatus.Stopped)
            return outputFile

        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recording", e)
            return null
        }
    }

    fun isRecording(): Boolean = isRecording

    fun getRecordingDuration(): Int {
        return if (outputFile != null && outputFile!!.exists()) {
            val totalBytes = outputFile!!.length()
            (totalBytes / (16000 * 2)).toInt() // Duration in seconds
        } else {
            0
        }
    }
}
