package com.oros.medical.data.models

import com.google.gson.annotations.SerializedName

data class Note(
    val id: Int,
    @SerializedName("patient_id")
    val patientId: Int,
    @SerializedName("doctor_id")
    val doctorId: Int,
    @SerializedName("surgery_id")
    val surgeryId: Int?,
    @SerializedName("transcription_id")
    val transcriptionId: Int?,
    val title: String?,
    val content: String?
)

data class NoteCreate(
    @SerializedName("patient_id")
    val patientId: Int,
    @SerializedName("doctor_id")
    val doctorId: Int,
    @SerializedName("surgery_id")
    val surgeryId: Int? = null,
    @SerializedName("transcription_id")
    val transcriptionId: Int? = null,
    val title: String? = null,
    val content: String? = null
)

data class NoteUpdate(
    @SerializedName("patient_id")
    val patientId: Int? = null,
    @SerializedName("doctor_id")
    val doctorId: Int? = null,
    @SerializedName("surgery_id")
    val surgeryId: Int? = null,
    @SerializedName("transcription_id")
    val transcriptionId: Int? = null,
    val title: String? = null,
    val content: String? = null
)
