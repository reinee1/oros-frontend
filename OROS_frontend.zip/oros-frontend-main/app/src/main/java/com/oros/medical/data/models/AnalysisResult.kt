package com.oros.medical.data.models

import com.google.gson.annotations.SerializedName

data class AnalysisResult(
    val success: Boolean = false,
    val summary: String? = null,
    val keywords: List<String>? = null,
    val symptoms: List<String>? = null,
    val diagnoses: List<String>? = null,
    val medications: List<String>? = null,
    val procedures: List<String>? = null,

    @SerializedName("concerns_identified")
    val concerns: List<String>? = null,

    @SerializedName("actions_recommended")
    val actionsRecommended: List<String>? = null,

    @SerializedName("urgency_level")
    val urgencyLevel: Int? = null,

    val analysis: String? = null,
    val error: String? = null
)
