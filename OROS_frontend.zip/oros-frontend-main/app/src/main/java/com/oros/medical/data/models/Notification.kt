package com.oros.medical.data.models

import com.google.gson.annotations.SerializedName

enum class Priority {
    @SerializedName("low")
    LOW,
    @SerializedName("medium")
    MEDIUM,
    @SerializedName("high")
    HIGH,
    @SerializedName("urgent")
    URGENT
}

data class Notification(
    val id: Int,
    @SerializedName("doctor_id")
    val doctorId: Int,
    val title: String,
    val message: String,
    val priority: Priority,
    @SerializedName("is_read")
    val isRead: Boolean,
    @SerializedName("related_entity_type")
    val relatedEntityType: String?,
    @SerializedName("related_entity_id")
    val relatedEntityId: Int?,
    @SerializedName("read_at")
    val readAt: String?
)

data class NotificationCreate(
    @SerializedName("doctor_id")
    val doctorId: Int,
    val title: String,
    val message: String,
    val priority: Priority? = Priority.LOW,
    @SerializedName("related_entity_type")
    val relatedEntityType: String? = null,
    @SerializedName("related_entity_id")
    val relatedEntityId: Int? = null
)

data class NotificationUpdate(
    val title: String? = null,
    val message: String? = null,
    val priority: Priority? = null,
    @SerializedName("is_read")
    val isRead: Boolean? = null,
    @SerializedName("related_entity_type")
    val relatedEntityType: String? = null,
    @SerializedName("related_entity_id")
    val relatedEntityId: Int? = null,
    @SerializedName("read_at")
    val readAt: String? = null
)
