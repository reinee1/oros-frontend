package com.oros.medical.ui.recording

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isEmpty
import androidx.lifecycle.lifecycleScope
import com.example.oros.DashboardActivity
import com.example.oros.PatientsActivity
import com.example.oros.R
import com.example.oros.databinding.ActivityRecordingBinding
import com.google.android.material.snackbar.Snackbar
import com.oros.medical.data.models.ConnectionState
import com.oros.medical.data.models.RecordingState
import kotlinx.coroutines.launch
import java.util.Locale

class RecordingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRecordingBinding
    private val viewModel: RecordingViewModel by viewModels()

    private var patientId: Int = -1
    private var patientName: String = ""
    private var fromDefault: Boolean = false
    private var fromPatientList: Boolean = false

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startRecordingProcess()
        else showPermissionDeniedDialog()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecordingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        patientId = intent.getIntExtra("PATIENT_ID", -1)
        patientName = intent.getStringExtra("PATIENT_NAME") ?: "Unknown Patient"
        fromDefault = intent.getBooleanExtra("FROM_DEFAULT", false)
        fromPatientList = intent.getBooleanExtra("FROM_PATIENT_LIST", false)

        if (patientId == -1) {
            // Allow opening without patient - user can select later
            // For now, use default values
            patientId = 1
            patientName = "Default Patient"
            fromDefault = true
        }

        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        // Back button click - cancel recording if in progress, then navigate back
        binding.backButton.setOnClickListener {
            when (viewModel.recordingState.value) {
                is RecordingState.Recording, is RecordingState.Processing -> {
                    // If recording, show cancel dialog
                    showCancelDialog()
                }
                else -> {
                    // If not recording, just navigate back
                    navigateBack()
                }
            }
        }

        // Record orb click
        binding.recordOrb.setOnClickListener {
            if (viewModel.recordingState.value is RecordingState.Idle) {
                checkPermissionAndRecord()
            }
        }

        // Tap to record/pause text is clickable too
        binding.tapToRecordText.setOnClickListener {
            if (viewModel.recordingState.value is RecordingState.Idle) {
                checkPermissionAndRecord()
            }
        }

        binding.tapToPauseText.setOnClickListener {
            if (viewModel.recordingState.value is RecordingState.Recording) {
                viewModel.stopRecording()
            }
        }

        // Make waveform and duration clickable when recording
        binding.waveformView.setOnClickListener {
            if (viewModel.recordingState.value is RecordingState.Recording) {
                viewModel.stopRecording()
            }
        }

        binding.textDuration.setOnClickListener {
            if (viewModel.recordingState.value is RecordingState.Recording) {
                viewModel.stopRecording()
            }
        }

        // Make entire recording controls area clickable
        binding.recordingControls.setOnClickListener {
            when (viewModel.recordingState.value) {
                is RecordingState.Idle -> checkPermissionAndRecord()
                is RecordingState.Recording -> viewModel.stopRecording()
                else -> {}
            }
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.recordingState.collect { updateUIForState(it) }
        }

        lifecycleScope.launch {
            viewModel.connectionState.collect { updateConnectionStatus(it) }
        }

        lifecycleScope.launch {
            viewModel.transcriptionText.collect {
                updateTranscript(it)
            }
        }

        lifecycleScope.launch {
            viewModel.recordingDuration.collect {
                binding.textDuration.text = formatDuration(it)
            }
        }

        lifecycleScope.launch {
            viewModel.errorMessage.collect { msg ->
                Snackbar.make(binding.root, msg, Snackbar.LENGTH_LONG).show()
            }
        }

        lifecycleScope.launch {
            viewModel.analysisResult.collect { analysis ->
                if (analysis != null) {
                    binding.layoutAnalysis.visibility = android.view.View.VISIBLE
                    binding.textSummary.text = analysis.summary ?: "No summary"
                    // Urgency and other analysis details can be added to textSummary or textEntities
                }
            }
        }

        lifecycleScope.launch {
            viewModel.entities.collect { entities ->
                if (entities != null) {
                    val sb = StringBuilder()
                    entities.symptoms?.let {
                        if (it.isNotEmpty()) sb.append("Symptoms: ${it.joinToString()}\n")
                    }
                    entities.medications?.let {
                        if (it.isNotEmpty()) sb.append("Medications: ${it.joinToString()}\n")
                    }
                    entities.vitals?.let {
                        if (it.isNotEmpty()) sb.append("Vitals: ${it.joinToString { vital -> "${vital.type}: ${vital.value}" } }\n")
                    }
                    entities.bodyParts?.let {
                        if (it.isNotEmpty()) sb.append("Body Parts: ${it.joinToString()}\n")
                    }

                    if (sb.isNotEmpty()) {
                        binding.textEntities.text = sb.toString()
                        binding.layoutAnalysis.visibility = android.view.View.VISIBLE
                    }
                }
            }
        }
    }

    private fun checkPermissionAndRecord() {
        when {
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED -> startRecordingProcess()

            shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO) ->
                showPermissionRationaleDialog()

            else -> requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startRecordingProcess() {
        viewModel.startRecording(patientId)
    }

    private fun showCancelDialog() {
        AlertDialog.Builder(this)
            .setTitle("Cancel Recording")
            .setMessage("Are you sure you want to cancel? This will discard the recording.")
            .setPositiveButton("Yes") { _, _ ->
                viewModel.cancelRecording()
                navigateBack()
            }
            .setNegativeButton("No", null)
            .show()
    }

    private fun navigateBack() {
        // If came from patient list, go back to patient list
        if (fromPatientList) {
            val intent = Intent(this, PatientsActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
        } else {
            // Otherwise go to dashboard (home)
            val intent = Intent(this, DashboardActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
        }
        finish()
    }

    private fun showPermissionRationaleDialog() {
        AlertDialog.Builder(this)
            .setTitle("Microphone Permission Needed")
            .setMessage("The app needs this to record medical notes.")
            .setPositiveButton("Grant") { _, _ ->
                requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPermissionDeniedDialog() {
        AlertDialog.Builder(this)
            .setTitle("Permission Denied")
            .setMessage("Microphone permission is required.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun updateUIForState(state: RecordingState) {
        when (state) {
            is RecordingState.Idle -> {
                // Show idle state UI
                binding.recordOrb.visibility = android.view.View.VISIBLE
                binding.tapToRecordText.visibility = android.view.View.VISIBLE
                binding.tapToPauseText.visibility = android.view.View.GONE
                binding.textDuration.visibility = android.view.View.GONE
                binding.waveformView.visibility = android.view.View.GONE
                binding.textTranscriptionPlaceholder.visibility = android.view.View.VISIBLE
                binding.transcriptHeader.visibility = android.view.View.GONE
                binding.transcriptContent.visibility = android.view.View.GONE
                binding.layoutAnalysis.visibility = android.view.View.GONE
            }
            is RecordingState.Recording -> {
                // Show recording state UI
                binding.recordOrb.visibility = android.view.View.GONE
                binding.tapToRecordText.visibility = android.view.View.GONE
                binding.tapToPauseText.visibility = android.view.View.VISIBLE
                binding.textDuration.visibility = android.view.View.VISIBLE
                binding.waveformView.visibility = android.view.View.VISIBLE
                binding.textTranscriptionPlaceholder.visibility = android.view.View.GONE
                binding.transcriptHeader.visibility = android.view.View.VISIBLE
                binding.transcriptContent.visibility = android.view.View.VISIBLE
            }
            is RecordingState.Processing -> {
                binding.tapToPauseText.text = "Processing..."
                binding.waveformView.visibility = android.view.View.VISIBLE
            }
            is RecordingState.Completed -> {
                binding.recordOrb.visibility = android.view.View.VISIBLE
                binding.tapToRecordText.visibility = android.view.View.VISIBLE
                binding.tapToRecordText.text = "New Recording"
                binding.tapToPauseText.visibility = android.view.View.GONE
                binding.textDuration.visibility = android.view.View.GONE
                binding.waveformView.visibility = android.view.View.GONE
                binding.layoutAnalysis.visibility = android.view.View.VISIBLE
            }
            is RecordingState.Error -> {
                binding.recordOrb.visibility = android.view.View.VISIBLE
                binding.tapToRecordText.visibility = android.view.View.VISIBLE
                binding.tapToRecordText.text = "Retry"
                binding.tapToPauseText.visibility = android.view.View.GONE
                binding.textDuration.visibility = android.view.View.GONE
                binding.waveformView.visibility = android.view.View.GONE
                Toast.makeText(this, "Error: ${state.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateConnectionStatus(state: ConnectionState) {
        // Connection status can be shown in UI if needed
        // For now, it's handled internally
    }

    private fun formatDuration(seconds: Int): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s)
    }

    private fun updateTranscript(text: String) {
        if (text.isEmpty()) {
            binding.textTranscriptionPlaceholder.visibility = android.view.View.VISIBLE
            binding.transcriptContent.visibility = android.view.View.GONE
        } else {
            binding.textTranscriptionPlaceholder.visibility = android.view.View.GONE
            binding.transcriptContent.visibility = android.view.View.VISIBLE
            // TODO: Implement chat bubble UI for transcript
            // For now, just show the text
            if (binding.transcriptContent.isEmpty()) {
                val textView = TextView(this).apply {
                    setTextColor(ContextCompat.getColor(this@RecordingActivity, R.color.oros_text_secondary))
                    textSize = 14f
                    this.text = text
                    setPadding(0, 8, 0, 8)
                }
                binding.transcriptContent.addView(textView)
            } else {
                (binding.transcriptContent.getChildAt(0) as? TextView)?.text = text
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}
