package com.oros.medical.data.network

import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.*
import okhttp3.*
import okio.ByteString
import com.oros.medical.data.models.*
import com.oros.medical.utils.Constants
import com.google.gson.Gson
import java.util.concurrent.TimeUnit

class WebSocketManager {

    private var webSocket: WebSocket? = null
    private val gson = Gson()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _transcriptionUpdates = MutableSharedFlow<TranscriptionUpdate>(
        replay = 0,
        extraBufferCapacity = 10,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val transcriptionUpdates: SharedFlow<TranscriptionUpdate> = _transcriptionUpdates.asSharedFlow()

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    fun connect(transcriptionId: Int) {
        _connectionState.value = ConnectionState.Connecting

        // Use correct WebSocket URL based on BASE_URL
        val wsUrl = Constants.BASE_URL
            .replace("http://", "ws://")
            .replace("https://", "wss://")
            .trimEnd('/')

        val request = Request.Builder()
            .url("${wsUrl}/ws/transcribe/$transcriptionId")
            .build()

        Log.d("WebSocket", "Connecting to: ${wsUrl}/ws/transcribe/$transcriptionId")
        webSocket = client.newWebSocket(request, socketListener)
    }

    fun disconnect() {
        webSocket?.close(1000, "Closing")
        _connectionState.value = ConnectionState.Disconnected
    }

    fun sendAudioChunk(chunk: ByteArray, index: Int, isFinal: Boolean) {
        val base64Chunk = android.util.Base64.encodeToString(chunk, android.util.Base64.NO_WRAP)
        val msg = AudioChunkMessage(chunk = base64Chunk, index = index, isFinal = isFinal)
        val json = gson.toJson(msg)
        webSocket?.send(json)
    }

    fun cancelTranscription() {
        val msg = CancelMessage()
        val json = gson.toJson(msg)
        webSocket?.send(json)
    }

    private val socketListener = object : WebSocketListener() {

        override fun onOpen(webSocket: WebSocket, response: Response) {
            _connectionState.value = ConnectionState.Connected
            Log.d("WebSocket", "Connected")
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            try {
                val update = gson.fromJson(text, TranscriptionUpdate::class.java)
                _transcriptionUpdates.tryEmit(update)
            } catch (e: Exception) {
                Log.e("WebSocket", "Error parsing message", e)
            }
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            Log.d("WebSocket", "Binary message received")
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            _connectionState.value = ConnectionState.Disconnected
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            _connectionState.value = ConnectionState.Error
            Log.e("WebSocket", "Error: ${t.message}")
        }
    }
}
