package com.oros.medical.domain

sealed class RecordingStatus {
    object Started : RecordingStatus()
    data class Recording(val durationSeconds: Int) : RecordingStatus()
    object Stopped : RecordingStatus()
    data class Error(val message: String) : RecordingStatus()
}
