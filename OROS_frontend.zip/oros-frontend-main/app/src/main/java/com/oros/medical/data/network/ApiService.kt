package com.oros.medical.data.network

import com.oros.medical.data.models.*
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {

    @POST("login")
    suspend fun login(@Body request: LoginRequest): LoginResponse

    @POST("transcribe")
    suspend fun transcribe(@Body request: TranscriptionRequest): TranscriptionResponse
}
