package com.oros.medical.data.models

data class TranscriptionRequest(
    val patientId: Int,
    val audio: String
)
