package com.oros.medical.data.models

import com.google.gson.annotations.SerializedName

data class MedicalEntities(
    val symptoms: List<String>? = null,
    val medications: List<String>? = null,
    val vitals: List<VitalSign>? = null,

    @SerializedName("body_parts")
    val bodyParts: List<String>? = null
)

data class VitalSign(
    val type: String,
    val value: String
)
