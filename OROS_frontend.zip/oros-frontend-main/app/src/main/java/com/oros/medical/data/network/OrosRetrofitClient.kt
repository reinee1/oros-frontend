package com.oros.medical.data.network

import android.content.Context
import com.google.gson.GsonBuilder
import com.oros.medical.utils.Constants
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object OrosRetrofitClient {

    @Volatile
    private var orosApiService: OrosApiService? = null

    /**
     * Initialize the Retrofit client with application context
     * This should be called once in Application class or before first use
     */
    fun initialize(context: Context) {
        if (orosApiService == null) {
            synchronized(this) {
                if (orosApiService == null) {
                    orosApiService = createApiService(context)
                }
            }
        }
    }

    /**
     * Get the API service instance
     * Make sure to call initialize() before using this
     */
    fun getApiService(): OrosApiService {
        return orosApiService ?: throw IllegalStateException(
            "OrosRetrofitClient not initialized. Call initialize(context) first."
        )
    }

    private fun createApiService(context: Context): OrosApiService {
        val gson = GsonBuilder()
            .setLenient()
            .create()

        // Create logging interceptor
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        // Create OkHttpClient with interceptors
        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(AuthInterceptor(context))
            .addInterceptor(loggingInterceptor)
            .connectTimeout(Constants.NETWORK_TIMEOUT, TimeUnit.SECONDS)
            .readTimeout(Constants.NETWORK_TIMEOUT, TimeUnit.SECONDS)
            .writeTimeout(Constants.NETWORK_TIMEOUT, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(Constants.BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()

        return retrofit.create(OrosApiService::class.java)
    }

    /**
     * Reset the client (useful for testing or after logout)
     */
    fun reset() {
        synchronized(this) {
            orosApiService = null
        }
    }
}
