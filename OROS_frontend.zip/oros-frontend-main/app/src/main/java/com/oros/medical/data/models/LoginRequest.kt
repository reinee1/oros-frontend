package com.oros.medical.data.models

data class LoginRequest(
    val email: String,
    val password: String
)