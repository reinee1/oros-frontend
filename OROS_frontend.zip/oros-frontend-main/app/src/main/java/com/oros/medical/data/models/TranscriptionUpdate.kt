package com.oros.medical.data.models

import com.google.gson.annotations.SerializedName

data class TranscriptionUpdate(
    val type: String, // "transcription_update", "status", "analysis_complete", "complete", "error"

    val text: String? = null,  // Current chunk text

    @SerializedName("full_text")
    val fullText: String? = null,  // Accumulated text

    @SerializedName("is_partial")
    val isPartial: Boolean? = null,

    @SerializedName("chunk_index")
    val chunkIndex: Int? = null,

    val confidence: Float? = null,
    val message: String? = null,
    val entities: MedicalEntities? = null,
    val analysis: AnalysisResult? = null,

    @SerializedName("transcription_id")
    val transcriptionId: Int? = null
)

