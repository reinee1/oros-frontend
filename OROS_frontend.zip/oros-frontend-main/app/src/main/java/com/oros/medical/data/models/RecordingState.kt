package com.oros.medical.data.models

sealed class RecordingState {
    object Idle : RecordingState()
    object Recording : RecordingState()
    object Processing : RecordingState()
    object Completed : RecordingState()
    data class Error(val message: String) : RecordingState()
}
