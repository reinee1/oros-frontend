package com.oros.medical.data.models

import com.google.gson.annotations.SerializedName

data class AudioChunkMessage(
    val type: String = "audio_chunk",

    @SerializedName("data")
    val chunk: String,

    @SerializedName("chunk_index")
    val index: Int,

    @SerializedName("is_final")
    val isFinal: Boolean
)
