package com.oros.medical.data.models

import com.google.gson.annotations.SerializedName

enum class PatientStatus {
    @SerializedName("active")
    ACTIVE,
    @SerializedName("archived")
    ARCHIVED
}

data class Patient(
    val id: Int,
    @SerializedName("first_name")
    val firstName: String,
    @SerializedName("last_name")
    val lastName: String,
    val email: String?,
    val phone: String?,
    val status: PatientStatus
)

data class PatientDetail(
    val id: Int,
    @SerializedName("first_name")
    val firstName: String,
    @SerializedName("last_name")
    val lastName: String,
    val email: String?,
    val phone: String?,
    val gender: String?,
    @SerializedName("blood_type")
    val bloodType: String?,
    val allergies: String?,
    @SerializedName("medical_history")
    val medicalHistory: String?,
    @SerializedName("insurance_info")
    val insuranceInfo: String?,
    @SerializedName("emergency_contact_name")
    val emergencyContactName: String?,
    @SerializedName("emergency_contact_phone")
    val emergencyContactPhone: String?,
    val address: String?,
    @SerializedName("profile_image_url")
    val profileImageUrl: String?,
    val status: PatientStatus
)

data class PatientCreate(
    @SerializedName("first_name")
    val firstName: String,
    @SerializedName("last_name")
    val lastName: String,
    val email: String? = null,
    val phone: String? = null,
    val gender: String? = null,
    @SerializedName("blood_type")
    val bloodType: String? = null,
    val allergies: String? = null,
    @SerializedName("medical_history")
    val medicalHistory: String? = null,
    @SerializedName("insurance_info")
    val insuranceInfo: String? = null,
    @SerializedName("emergency_contact_name")
    val emergencyContactName: String? = null,
    @SerializedName("emergency_contact_phone")
    val emergencyContactPhone: String? = null,
    val address: String? = null,
    @SerializedName("profile_image_url")
    val profileImageUrl: String? = null
)

data class PatientUpdate(
    @SerializedName("first_name")
    val firstName: String? = null,
    @SerializedName("last_name")
    val lastName: String? = null,
    val email: String? = null,
    val phone: String? = null,
    val gender: String? = null,
    @SerializedName("blood_type")
    val bloodType: String? = null,
    val allergies: String? = null,
    @SerializedName("medical_history")
    val medicalHistory: String? = null,
    @SerializedName("insurance_info")
    val insuranceInfo: String? = null,
    @SerializedName("emergency_contact_name")
    val emergencyContactName: String? = null,
    @SerializedName("emergency_contact_phone")
    val emergencyContactPhone: String? = null,
    val address: String? = null,
    @SerializedName("profile_image_url")
    val profileImageUrl: String? = null,
    val status: PatientStatus? = null
)
