package com.oros.medical.data.models

data class PatientResponse(
    val id: Int,
    val name: String,
    val age: Int
)
