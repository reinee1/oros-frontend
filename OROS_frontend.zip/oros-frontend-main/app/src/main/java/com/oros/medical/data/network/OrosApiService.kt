package com.oros.medical.data.network

import com.oros.medical.data.models.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface OrosApiService {

    // ==================== AUTHENTICATION ====================

    @FormUrlEncoded
    @POST("auth/login")
    suspend fun login(
        @Field("username") email: String,
        @Field("password") password: String
    ): Response<TokenResponse>

    @GET("auth/me")
    suspend fun getCurrentDoctor(): Response<DoctorMe>

    // ==================== DOCTORS ====================

    @POST("doctors")
    suspend fun createDoctor(@Body doctor: DoctorCreate): Response<Doctor>

    @GET("doctors")
    suspend fun listDoctors(
        @Query("limit") limit: Int = 20,
        @Query("offset") offset: Int = 0,
        @Query("search") search: String? = null
    ): Response<List<Doctor>>

    @GET("doctors/{doctor_id}")
    suspend fun getDoctor(@Path("doctor_id") doctorId: Int): Response<Doctor>

    @PATCH("doctors/{doctor_id}")
    suspend fun updateDoctor(
        @Path("doctor_id") doctorId: Int,
        @Body update: DoctorUpdate
    ): Response<Doctor>

    @DELETE("doctors/{doctor_id}")
    suspend fun deleteDoctor(@Path("doctor_id") doctorId: Int): Response<Unit>

    // ==================== PATIENTS ====================

    @POST("patients")
    suspend fun createPatient(@Body patient: PatientCreate): Response<Patient>

    @GET("patients")
    suspend fun listPatients(
        @Query("limit") limit: Int = 20,
        @Query("offset") offset: Int = 0,
        @Query("search") search: String? = null
    ): Response<List<Patient>>

    @GET("patients/my")
    suspend fun listMyPatients(): Response<List<Patient>>

    @GET("patients/{patient_id}")
    suspend fun getPatient(@Path("patient_id") patientId: Int): Response<PatientDetail>

    @PATCH("patients/{patient_id}")
    suspend fun updatePatient(
        @Path("patient_id") patientId: Int,
        @Body update: PatientUpdate
    ): Response<Patient>

    @DELETE("patients/{patient_id}")
    suspend fun deletePatient(@Path("patient_id") patientId: Int): Response<Unit>

    // ==================== NOTES ====================

    @POST("notes")
    suspend fun createNote(@Body note: NoteCreate): Response<Note>

    @GET("notes")
    suspend fun listNotes(
        @Query("limit") limit: Int = 20,
        @Query("offset") offset: Int = 0,
        @Query("patient_id") patientId: Int? = null,
        @Query("doctor_id") doctorId: Int? = null,
        @Query("surgery_id") surgeryId: Int? = null,
        @Query("has_transcription") hasTranscription: Boolean? = null,
        @Query("search") search: String? = null
    ): Response<List<Note>>

    @GET("notes/{note_id}")
    suspend fun getNote(@Path("note_id") noteId: Int): Response<Note>

    @PATCH("notes/{note_id}")
    suspend fun updateNote(
        @Path("note_id") noteId: Int,
        @Body update: NoteUpdate
    ): Response<Note>

    @DELETE("notes/{note_id}")
    suspend fun deleteNote(@Path("note_id") noteId: Int): Response<Unit>

    // ==================== TRANSCRIPTIONS ====================

    @POST("transcriptions")
    suspend fun createTranscription(@Body transcription: TranscriptionCreate): Response<Transcription>

    @GET("transcriptions")
    suspend fun listTranscriptions(
        @Query("limit") limit: Int = 20,
        @Query("offset") offset: Int = 0,
        @Query("doctor_id") doctorId: Int? = null,
        @Query("patient_id") patientId: Int? = null,
        @Query("status") status: TranscriptionStatus? = null,
        @Query("language") language: String? = null,
        @Query("completed_from") completedFrom: String? = null,
        @Query("completed_to") completedTo: String? = null,
        @Query("search") search: String? = null
    ): Response<List<Transcription>>

    @GET("transcriptions/{transcription_id}")
    suspend fun getTranscription(@Path("transcription_id") transcriptionId: Int): Response<Transcription>

    @PATCH("transcriptions/{transcription_id}")
    suspend fun updateTranscription(
        @Path("transcription_id") transcriptionId: Int,
        @Body update: TranscriptionUpdateModel
    ): Response<Transcription>

    @DELETE("transcriptions/{transcription_id}")
    suspend fun deleteTranscription(@Path("transcription_id") transcriptionId: Int): Response<Unit>

    // ==================== SURGERIES ====================

    @POST("surgeries")
    suspend fun createSurgery(@Body surgery: SurgeryCreate): Response<Surgery>

    @GET("surgeries")
    suspend fun listSurgeries(
        @Query("limit") limit: Int = 20,
        @Query("offset") offset: Int = 0,
        @Query("patient_id") patientId: Int? = null,
        @Query("doctor_id") doctorId: Int? = null,
        @Query("operating_room_id") operatingRoomId: Int? = null,
        @Query("status") status: SurgeryStatus? = null,
        @Query("date_from") dateFrom: String? = null,
        @Query("date_to") dateTo: String? = null,
        @Query("search") search: String? = null
    ): Response<List<Surgery>>

    @GET("surgeries/{surgery_id}")
    suspend fun getSurgery(@Path("surgery_id") surgeryId: Int): Response<Surgery>

    @PATCH("surgeries/{surgery_id}")
    suspend fun updateSurgery(
        @Path("surgery_id") surgeryId: Int,
        @Body update: SurgeryUpdate
    ): Response<Surgery>

    @DELETE("surgeries/{surgery_id}")
    suspend fun deleteSurgery(@Path("surgery_id") surgeryId: Int): Response<Unit>

    // ==================== OPERATING ROOMS ====================

    @POST("operating-rooms")
    suspend fun createOperatingRoom(@Body room: OperatingRoomCreate): Response<OperatingRoom>

    @GET("operating-rooms")
    suspend fun listOperatingRooms(
        @Query("limit") limit: Int = 20,
        @Query("offset") offset: Int = 0,
        @Query("status") status: RoomStatus? = null,
        @Query("capacity_min") capacityMin: Int? = null,
        @Query("capacity_max") capacityMax: Int? = null,
        @Query("search") search: String? = null
    ): Response<List<OperatingRoom>>

    @GET("operating-rooms/{room_id}")
    suspend fun getOperatingRoom(@Path("room_id") roomId: Int): Response<OperatingRoom>

    @PATCH("operating-rooms/{room_id}")
    suspend fun updateOperatingRoom(
        @Path("room_id") roomId: Int,
        @Body update: OperatingRoomUpdate
    ): Response<OperatingRoom>

    @DELETE("operating-rooms/{room_id}")
    suspend fun deleteOperatingRoom(@Path("room_id") roomId: Int): Response<Unit>

    // ==================== NOTIFICATIONS ====================

    @POST("notifications")
    suspend fun createNotification(@Body notification: NotificationCreate): Response<Notification>

    @GET("notifications")
    suspend fun listNotifications(
        @Query("limit") limit: Int = 20,
        @Query("offset") offset: Int = 0,
        @Query("doctor_id") doctorId: Int? = null,
        @Query("is_read") isRead: Boolean? = null,
        @Query("priority") priority: Priority? = null,
        @Query("related_entity_type") relatedEntityType: String? = null,
        @Query("created_from") createdFrom: String? = null,
        @Query("created_to") createdTo: String? = null,
        @Query("search") search: String? = null
    ): Response<List<Notification>>

    @GET("notifications/{notification_id}")
    suspend fun getNotification(@Path("notification_id") notificationId: Int): Response<Notification>

    @PATCH("notifications/{notification_id}")
    suspend fun updateNotification(
        @Path("notification_id") notificationId: Int,
        @Body update: NotificationUpdate
    ): Response<Notification>

    @DELETE("notifications/{notification_id}")
    suspend fun deleteNotification(@Path("notification_id") notificationId: Int): Response<Unit>

    @POST("notifications/{notification_id}/read")
    suspend fun markNotificationRead(@Path("notification_id") notificationId: Int): Response<Notification>
}
