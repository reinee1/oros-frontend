package com.oros.medical.data.models

data class DoctorInfo(
    val id: Int,
    val name: String
)
