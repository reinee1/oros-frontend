package com.oros.medical.data.models

data class CancelMessage(
    val type: String = "cancel"
)