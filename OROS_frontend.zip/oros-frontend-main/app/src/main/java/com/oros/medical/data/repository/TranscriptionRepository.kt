package com.oros.medical.data.repository

import android.app.Application
import android.util.Log
import android.util.Base64
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import com.oros.medical.data.models.*
import com.oros.medical.data.network.OrosRetrofitClient
import com.oros.medical.data.network.WebSocketManager
import com.oros.medical.utils.Constants
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class TranscriptionRepository(private val application: Application) {

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _transcriptionUpdates = MutableSharedFlow<TranscriptionUpdate>(replay = 0, extraBufferCapacity = 10)
    val transcriptionUpdates: SharedFlow<TranscriptionUpdate> = _transcriptionUpdates.asSharedFlow()

    private val webSocketManager = WebSocketManager()
    private var currentTranscriptionId: Int? = null

    suspend fun createTranscription(patientId: Int): Result<TranscriptionResponse> {
        return withContext(Dispatchers.IO) {
            try {
                _connectionState.value = ConnectionState.Connecting

                // Get doctor ID from SharedPreferences
                val prefs = application.getSharedPreferences(Constants.PREFS_NAME, android.content.Context.MODE_PRIVATE)
                val doctorId = prefs.getInt(Constants.KEY_DOCTOR_ID, 0)

                // Create transcription via API first
                val client = OkHttpClient()
                val json = JSONObject()
                json.put("patient_id", patientId)
                if (doctorId > 0) {
                    json.put("doctor_id", doctorId)
                }

                val body = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
                val request = Request.Builder()
                    .url("${Constants.BASE_URL}transcriptions")
                    .post(body)
                    .build()

                Log.d("Repository", "Creating transcription via API...")
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()

                if (response.isSuccessful && responseBody != null) {
                    val jsonResponse = JSONObject(responseBody)
                    val transcriptionId = jsonResponse.getInt("id")
                    currentTranscriptionId = transcriptionId

                    Log.d("Repository", "Transcription created with ID: $transcriptionId")
                    _connectionState.value = ConnectionState.Connected

                    Result.success(TranscriptionResponse(id = transcriptionId))
                } else {
                    Log.e("Repository", "Failed to create transcription: ${response.code} - $responseBody")
                    _connectionState.value = ConnectionState.Error
                    Result.failure(Exception("Failed to create transcription: ${response.code}"))
                }
            } catch (e: Exception) {
                Log.e("Repository", "Failed to create transcription", e)
                _connectionState.value = ConnectionState.Error
                Result.failure(e)
            }
        }
    }

    fun connectWebSocket(transcriptionId: Int) {
        Log.d("Repository", "Connecting to WebSocket for transcription $transcriptionId")
        webSocketManager.connect(transcriptionId) { update ->
            Log.d("Repository", "Received WebSocket update: ${update.type}")
            _transcriptionUpdates.tryEmit(update)

            // Update connection state based on message type
            when (update.type) {
                "error" -> _connectionState.value = ConnectionState.Error
                "complete" -> _connectionState.value = ConnectionState.Disconnected
            }
        }
        _connectionState.value = ConnectionState.Connected
    }

    fun disconnectWebSocket() {
        Log.d("Repository", "Disconnecting WebSocket")
        webSocketManager.disconnect()
        _connectionState.value = ConnectionState.Disconnected
    }

    fun sendAudioChunk(chunk: ByteArray, index: Int, isFinal: Boolean) {
        val base64Chunk = Base64.encodeToString(chunk, Base64.NO_WRAP)
        Log.d("Repository", "Sending audio chunk: index=$index, size=${chunk.size}, isFinal=$isFinal")
        webSocketManager.sendAudioChunk(base64Chunk, index, isFinal)
    }

    fun cancelTranscription() {
        Log.d("Repository", "Cancelling transcription")
        webSocketManager.sendCancel()
        disconnectWebSocket()
    }
}
