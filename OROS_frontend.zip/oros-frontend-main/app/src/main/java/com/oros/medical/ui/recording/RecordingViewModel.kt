package com.oros.medical.ui.recording

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.oros.medical.data.models.*
import com.oros.medical.data.repository.TranscriptionRepository
import com.oros.medical.domain.AudioRecorder
import com.oros.medical.domain.RecordingStatus
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

class RecordingViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = TranscriptionRepository(application)
    private val recorder = AudioRecorder()

    private val _recordingState = MutableStateFlow<RecordingState>(RecordingState.Idle)
    val recordingState: StateFlow<RecordingState> = _recordingState

    val connectionState: StateFlow<ConnectionState> = repo.connectionState

    private val _text = MutableStateFlow("")
    val transcriptionText = _text.asStateFlow()

    private val _duration = MutableStateFlow(0)
    val recordingDuration = _duration.asStateFlow()

    private val _analysis = MutableStateFlow<AnalysisResult?>(null)
    val analysisResult = _analysis.asStateFlow()

    private val _entities = MutableStateFlow<MedicalEntities?>(null)
    val entities = _entities.asStateFlow()

    private val _status = MutableStateFlow<String?>(null)
    val statusMessage = _status.asStateFlow()

    private val _error = MutableSharedFlow<String>()
    val errorMessage: SharedFlow<String> = _error

    private var transcriptionId: Int? = null
    private var chunkIndex = 0

    private var chunkJob: Job? = null
    private var timerJob: Job? = null

    init {
        viewModelScope.launch {
            repo.transcriptionUpdates.collect { update -> handleUpdate(update) }
        }
        viewModelScope.launch {
            recorder.recordingStatus.collect { handleRecordingStatus(it) }
        }
    }

    fun startRecording(patientId: Int) {
        if (_recordingState.value != RecordingState.Idle) return

        viewModelScope.launch {
            try {
                Log.d("VM", "Starting recording for patient $patientId")
                _recordingState.value = RecordingState.Recording
                _text.value = ""
                chunkIndex = 0

                val create = repo.createTranscription(patientId)
                if (!create.isSuccess) {
                    Log.e("VM", "Failed to create transcription")
                    _recordingState.value = RecordingState.Error("Failed to create session")
                    _error.emit("Failed to create session")
                    return@launch
                }

                transcriptionId = create.getOrNull()?.id
                Log.d("VM", "Transcription ID: $transcriptionId")
                repo.connectWebSocket(transcriptionId!!)

                delay(400)

                val file =
                    File(getApplication<Application>().cacheDir, "rec_${System.currentTimeMillis()}.wav")

                Log.d("VM", "Starting audio recorder...")
                if (!recorder.startRecording(file)) {
                    Log.e("VM", "Failed to start recorder")
                    _error.emit("Failed to start mic")
                    _recordingState.value = RecordingState.Error("Mic error")
                    return@launch
                }

                Log.d("VM", "Recorder started successfully")
                startChunkSender()
                startTimer()

            } catch (e: Exception) {
                Log.e("VM", "Start error", e)
                e.printStackTrace()
                _error.emit(e.message ?: "Unknown error")
                _recordingState.value = RecordingState.Error(e.message ?: "")
            }
        }
    }

    fun stopRecording() {
        if (_recordingState.value != RecordingState.Recording) return

        viewModelScope.launch {
            Log.d("VM", "Stopping recording...")
            _recordingState.value = RecordingState.Processing

            chunkJob?.cancel()
            timerJob?.cancel()

            Log.d("VM", "Stopping recorder...")
            val file = recorder.stopRecording() ?: run {
                Log.e("VM", "Failed to save audio file")
                _error.emit("Failed to save audio")
                _recordingState.value = RecordingState.Error("Failed to save")
                return@launch
            }

            Log.d("VM", "Reading audio file: ${file.absolutePath}, size: ${file.length()} bytes")
            val bytes = file.readBytes()
            Log.d("VM", "Sending final audio chunk: ${bytes.size} bytes")
            repo.sendAudioChunk(bytes, chunkIndex++, true)
            _status.value = "Processing transcription..."
            Log.d("VM", "Audio sent, waiting for server response...")
        }
    }

    fun cancelRecording() {
        viewModelScope.launch {
            chunkJob?.cancel()
            timerJob?.cancel()
            recorder.stopRecording()
            repo.cancelTranscription()
            _recordingState.value = RecordingState.Idle
            _text.value = ""
            _duration.value = 0
        }
    }

    private fun startChunkSender() {
        chunkJob = viewModelScope.launch {
            recorder.audioChunks.collect { chunk ->
                repo.sendAudioChunk(chunk, chunkIndex++, false)
            }
        }
    }

    private fun startTimer() {
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _duration.value = recorder.getRecordingDuration()
            }
        }
    }

    private fun handleUpdate(update: TranscriptionUpdate) {
        when (update.type) {
            "transcription_update" -> {
                update.fullText?.let { _text.value = it }
                update.entities?.let { _entities.value = it }
            }
            "status" -> _status.value = update.message
            "analysis_complete" -> {
                _analysis.value = update.analysis
                _entities.value = update.entities
            }
            "complete" -> {
                _recordingState.value = RecordingState.Completed
                repo.disconnectWebSocket()
                _status.value = "Done!"
            }
            "error" -> {
                _recordingState.value = RecordingState.Error(update.message ?: "")
                viewModelScope.launch { _error.emit(update.message ?: "Error") }
            }
        }
    }

    private fun handleRecordingStatus(status: RecordingStatus) {
        when (status) {
            is RecordingStatus.Started -> {}
            is RecordingStatus.Recording -> _duration.value = status.durationSeconds
            is RecordingStatus.Stopped -> {}
            is RecordingStatus.Error -> {
                viewModelScope.launch { _error.emit(status.message) }
            }
        }
    }

    fun getTranscriptionId(): Int? = transcriptionId
}
