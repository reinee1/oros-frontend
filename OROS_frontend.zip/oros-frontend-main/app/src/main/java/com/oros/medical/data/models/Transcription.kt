package com.oros.medical.data.models

import com.google.gson.annotations.SerializedName

enum class TranscriptionStatus {
    @SerializedName("pending")
    PENDING,
    @SerializedName("processing")
    PROCESSING,
    @SerializedName("completed")
    COMPLETED,
    @SerializedName("failed")
    FAILED
}

data class Transcription(
    val id: Int,
    @SerializedName("doctor_id")
    val doctorId: Int?,
    @SerializedName("patient_id")
    val patientId: Int?,
    @SerializedName("audio_file_url")
    val audioFileUrl: String?,
    @SerializedName("audio_duration_seconds")
    val audioDurationSeconds: Int?,
    @SerializedName("transcription_text")
    val transcriptionText: String?,
    @SerializedName("transcription_status")
    val transcriptionStatus: TranscriptionStatus,
    @SerializedName("confidence_score")
    val confidenceScore: Float?,
    val language: String?,
    @SerializedName("completed_at")
    val completedAt: String?
)

data class TranscriptionCreate(
    @SerializedName("doctor_id")
    val doctorId: Int? = null,
    @SerializedName("patient_id")
    val patientId: Int? = null,
    @SerializedName("audio_file_url")
    val audioFileUrl: String? = null,
    @SerializedName("audio_duration_seconds")
    val audioDurationSeconds: Int? = null,
    @SerializedName("transcription_text")
    val transcriptionText: String? = null,
    @SerializedName("transcription_status")
    val transcriptionStatus: TranscriptionStatus? = TranscriptionStatus.PENDING,
    @SerializedName("confidence_score")
    val confidenceScore: Float? = null,
    val language: String? = null,
    @SerializedName("completed_at")
    val completedAt: String? = null
)

data class TranscriptionUpdateModel(
    @SerializedName("doctor_id")
    val doctorId: Int? = null,
    @SerializedName("patient_id")
    val patientId: Int? = null,
    @SerializedName("audio_file_url")
    val audioFileUrl: String? = null,
    @SerializedName("audio_duration_seconds")
    val audioDurationSeconds: Int? = null,
    @SerializedName("transcription_text")
    val transcriptionText: String? = null,
    @SerializedName("transcription_status")
    val transcriptionStatus: TranscriptionStatus? = null,
    @SerializedName("confidence_score")
    val confidenceScore: Float? = null,
    val language: String? = null,
    @SerializedName("completed_at")
    val completedAt: String? = null
)
