package com.oros.medical.data.models

data class LoginResponse(
    val token: String,
    val doctor: DoctorInfo
)
