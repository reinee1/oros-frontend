package com.oros.medical.data.network

import android.content.Context
import android.content.SharedPreferences
import com.oros.medical.utils.Constants
import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(context: Context) : Interceptor {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        Constants.PREFS_NAME,
        Context.MODE_PRIVATE
    )

    override fun intercept(chain: Interceptor.Chain): Response {
        val requestBuilder = chain.request().newBuilder()

        // Get the auth token from SharedPreferences
        val token = prefs.getString(Constants.KEY_AUTH_TOKEN, null)

        // Add Authorization header if token exists
        token?.let {
            requestBuilder.addHeader("Authorization", "Bearer $it")
        }

        return chain.proceed(requestBuilder.build())
    }
}
