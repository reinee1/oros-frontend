package com.oros.medical.data.models

import com.google.gson.annotations.SerializedName

enum class DoctorStatus {
    @SerializedName("active")
    ACTIVE,
    @SerializedName("inactive")
    INACTIVE
}

data class Doctor(
    val id: Int,
    @SerializedName("first_name")
    val firstName: String,
    @SerializedName("last_name")
    val lastName: String,
    val email: String,
    val phone: String?,
    val specialization: String?,
    @SerializedName("license_number")
    val licenseNumber: String?,
    @SerializedName("profile_image_url")
    val profileImageUrl: String?,
    val status: DoctorStatus
)

data class DoctorCreate(
    @SerializedName("first_name")
    val firstName: String,
    @SerializedName("last_name")
    val lastName: String,
    val email: String,
    val password: String,
    val phone: String? = null,
    val specialization: String? = null,
    @SerializedName("license_number")
    val licenseNumber: String? = null,
    @SerializedName("profile_image_url")
    val profileImageUrl: String? = null
)

data class DoctorUpdate(
    @SerializedName("first_name")
    val firstName: String? = null,
    @SerializedName("last_name")
    val lastName: String? = null,
    val email: String? = null,
    val password: String? = null,
    val phone: String? = null,
    val specialization: String? = null,
    @SerializedName("license_number")
    val licenseNumber: String? = null,
    @SerializedName("profile_image_url")
    val profileImageUrl: String? = null,
    val status: DoctorStatus? = null
)
