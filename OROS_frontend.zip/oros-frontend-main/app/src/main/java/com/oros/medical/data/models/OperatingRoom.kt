package com.oros.medical.data.models

import com.google.gson.annotations.SerializedName

enum class RoomStatus {
    @SerializedName("available")
    AVAILABLE,
    @SerializedName("occupied")
    OCCUPIED,
    @SerializedName("maintenance")
    MAINTENANCE,
    @SerializedName("reserved")
    RESERVED
}

data class OperatingRoom(
    val id: Int,
    @SerializedName("room_number")
    val roomNumber: String,
    @SerializedName("room_name")
    val roomName: String?,
    val capacity: Int?,
    val status: RoomStatus,
    val location: String?
)

data class OperatingRoomCreate(
    @SerializedName("room_number")
    val roomNumber: String,
    @SerializedName("room_name")
    val roomName: String? = null,
    val capacity: Int? = null,
    val status: RoomStatus? = RoomStatus.AVAILABLE,
    val location: String? = null
)

data class OperatingRoomUpdate(
    @SerializedName("room_number")
    val roomNumber: String? = null,
    @SerializedName("room_name")
    val roomName: String? = null,
    val capacity: Int? = null,
    val status: RoomStatus? = null,
    val location: String? = null
)
