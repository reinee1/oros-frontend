package com.oros.medical.data.models

import com.google.gson.annotations.SerializedName

enum class SurgeryStatus {
    @SerializedName("scheduled")
    SCHEDULED,
    @SerializedName("in_progress")
    IN_PROGRESS,
    @SerializedName("completed")
    COMPLETED,
    @SerializedName("cancelled")
    CANCELLED
}

data class Surgery(
    val id: Int,
    @SerializedName("patient_id")
    val patientId: Int,
    @SerializedName("doctor_id")
    val doctorId: Int,
    @SerializedName("operating_room_id")
    val operatingRoomId: Int?,
    @SerializedName("surgery_type")
    val surgeryType: String?,
    @SerializedName("procedure_name")
    val procedureName: String?,
    @SerializedName("scheduled_date")
    val scheduledDate: String?,
    @SerializedName("scheduled_time")
    val scheduledTime: String?,
    @SerializedName("duration_minutes")
    val durationMinutes: Int?,
    @SerializedName("actual_start_time")
    val actualStartTime: String?,
    @SerializedName("actual_end_time")
    val actualEndTime: String?,
    val status: SurgeryStatus,
    @SerializedName("urgency_level")
    val urgencyLevel: Int?,
    val participants: String?,
    @SerializedName("pre_op_notes")
    val preOpNotes: String?,
    @SerializedName("post_op_notes")
    val postOpNotes: String?,
    val complications: String?
)

data class SurgeryCreate(
    @SerializedName("patient_id")
    val patientId: Int,
    @SerializedName("doctor_id")
    val doctorId: Int,
    @SerializedName("operating_room_id")
    val operatingRoomId: Int? = null,
    @SerializedName("surgery_type")
    val surgeryType: String? = null,
    @SerializedName("procedure_name")
    val procedureName: String? = null,
    @SerializedName("scheduled_date")
    val scheduledDate: String? = null,
    @SerializedName("scheduled_time")
    val scheduledTime: String? = null,
    @SerializedName("duration_minutes")
    val durationMinutes: Int? = null,
    @SerializedName("actual_start_time")
    val actualStartTime: String? = null,
    @SerializedName("actual_end_time")
    val actualEndTime: String? = null,
    val status: SurgeryStatus? = SurgeryStatus.SCHEDULED,
    @SerializedName("urgency_level")
    val urgencyLevel: Int? = null,
    val participants: String? = null,
    @SerializedName("pre_op_notes")
    val preOpNotes: String? = null,
    @SerializedName("post_op_notes")
    val postOpNotes: String? = null,
    val complications: String? = null
)

data class SurgeryUpdate(
    @SerializedName("patient_id")
    val patientId: Int? = null,
    @SerializedName("doctor_id")
    val doctorId: Int? = null,
    @SerializedName("operating_room_id")
    val operatingRoomId: Int? = null,
    @SerializedName("surgery_type")
    val surgeryType: String? = null,
    @SerializedName("procedure_name")
    val procedureName: String? = null,
    @SerializedName("scheduled_date")
    val scheduledDate: String? = null,
    @SerializedName("scheduled_time")
    val scheduledTime: String? = null,
    @SerializedName("duration_minutes")
    val durationMinutes: Int? = null,
    @SerializedName("actual_start_time")
    val actualStartTime: String? = null,
    @SerializedName("actual_end_time")
    val actualEndTime: String? = null,
    val status: SurgeryStatus? = null,
    @SerializedName("urgency_level")
    val urgencyLevel: Int? = null,
    val participants: String? = null,
    @SerializedName("pre_op_notes")
    val preOpNotes: String? = null,
    @SerializedName("post_op_notes")
    val postOpNotes: String? = null,
    val complications: String? = null
)
