package com.example.oros

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.oros.utils.setupFooterNavigation
import com.oros.medical.data.models.DoctorMe
import com.oros.medical.data.models.Note
import com.oros.medical.data.models.Surgery
import com.oros.medical.data.models.SurgeryStatus
import com.oros.medical.data.repository.OrosRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class DoctorProfileActivity : AppCompatActivity() {

    private lateinit var repository: OrosRepository
    private var currentDoctor: DoctorMe? = null
    private lateinit var doctorProfile: DoctorProfile

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor_profile)

        repository = OrosRepository(this)

        // Load data from API
        loadDoctorProfile()
        loadOperatingRoomSchedules()
        loadPatientNotes()

        setupNavigationShortcuts()
        setupEditButton()
        setupFooterNavigation()
    }

    private fun loadDoctorProfile() {
        lifecycleScope.launch {
            // First, load from SharedPreferences (cached data)
            val prefs = getSharedPreferences("DoctorProfile", MODE_PRIVATE)
            val savedFirstName = prefs.getString("firstName", null)
            val savedLastName = prefs.getString("lastName", null)
            val savedSpecialty = prefs.getString("specialty", null)
            val savedSubSpecialty = prefs.getString("subSpecialty", null)

            // Try to get current doctor from API
            val result = repository.getCurrentDoctor()
            result.onSuccess { doctor ->
                currentDoctor = doctor

                // Use saved names if available, otherwise use from API
                val firstName = savedFirstName ?: doctor.firstName
                val lastName = savedLastName ?: doctor.lastName

                // Try to get full doctor details
                val doctorResult = repository.getDoctor(doctor.id)
                doctorResult.onSuccess { fullDoctor ->
                    // Use API specialty if available, otherwise use saved
                    val specialty = fullDoctor.specialization ?: savedSpecialty ?: "Specialist"
                    val subSpecialty = savedSubSpecialty ?: "Medicine"

                    doctorProfile = DoctorProfile(
                        name = "Dr. $firstName $lastName",
                        specialty = specialty,
                        subSpecialty = subSpecialty,
                        profileImageRes = R.drawable.doctor_alex
                    )
                    renderDoctorDetails(doctorProfile)
                }.onFailure {
                    // Use cached data
                    doctorProfile = DoctorProfile(
                        name = "Dr. $firstName $lastName",
                        specialty = savedSpecialty ?: "Specialist",
                        subSpecialty = savedSubSpecialty ?: "Medicine",
                        profileImageRes = R.drawable.doctor_alex
                    )
                    renderDoctorDetails(doctorProfile)
                }
            }.onFailure { error ->
                // Use only cached data if API fails
                if (savedFirstName != null && savedLastName != null) {
                    doctorProfile = DoctorProfile(
                        name = "Dr. $savedFirstName $savedLastName",
                        specialty = savedSpecialty ?: "Specialist",
                        subSpecialty = savedSubSpecialty ?: "Medicine",
                        profileImageRes = R.drawable.doctor_alex
                    )
                    renderDoctorDetails(doctorProfile)
                } else {
                    Toast.makeText(this@DoctorProfileActivity,
                        "Failed to load profile: ${error.message}",
                        Toast.LENGTH_SHORT).show()
                    doctorProfile = DoctorProfile(
                        name = "Doctor",
                        specialty = "Specialist",
                        subSpecialty = "Medicine",
                        profileImageRes = R.drawable.doctor_alex
                    )
                    renderDoctorDetails(doctorProfile)
                }
            }
        }
    }

    private fun loadOperatingRoomSchedules() {
        lifecycleScope.launch {
            val result = repository.listSurgeries(
                limit = 10,
                status = SurgeryStatus.SCHEDULED
            )
            result.onSuccess { surgeries ->
                val schedules = surgeries.map { surgery ->
                    OperatingRoomSchedule(
                        label = "Surgery #${surgery.id}",
                        scheduledAt = formatScheduleTime(surgery.scheduledDate, surgery.scheduledTime),
                        status = mapSurgeryStatus(surgery.status)
                    )
                }
                renderOperatingRooms(schedules)
            }.onFailure { error ->
                Toast.makeText(this@DoctorProfileActivity,
                    "Failed to load surgeries: ${error.message}",
                    Toast.LENGTH_SHORT).show()
                renderOperatingRooms(emptyList())
            }
        }
    }

    private fun loadPatientNotes() {
        lifecycleScope.launch {
            val result = repository.listNotes(limit = 10)
            result.onSuccess { notes ->
                val patientNotes = notes.mapNotNull { note ->
                    // Fetch patient details for each note
                    val patientResult = repository.getPatient(note.patientId)
                    patientResult.getOrNull()?.let { patient ->
                        PatientNote(
                            patientName = "${patient.firstName} ${patient.lastName}",
                            patientDetails = patient.medicalHistory ?: "No details available",
                            todaySummary = note.title ?: "No title",
                            assessment = note.content ?: "No content"
                        )
                    }
                }
                renderPatientNotes(patientNotes)
            }.onFailure { error ->
                Toast.makeText(this@DoctorProfileActivity,
                    "Failed to load notes: ${error.message}",
                    Toast.LENGTH_SHORT).show()
                renderPatientNotes(emptyList())
            }
        }
    }

    private fun formatScheduleTime(date: String?, time: String?): String {
        if (date == null) return "Not scheduled"
        return try {
            val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val scheduledDate = formatter.parse(date)
            val today = Calendar.getInstance()
            val scheduleCalendar = Calendar.getInstance().apply {
                if (scheduledDate != null) this.time = scheduledDate
            }

            val dayText = when {
                isSameDay(today, scheduleCalendar) -> "Today"
                isTomorrow(today, scheduleCalendar) -> "Tomorrow"
                else -> SimpleDateFormat("MMM dd", Locale.getDefault()).format(scheduledDate ?: Date())
            }

            "$dayText · ${time ?: "Time TBD"}"
        } catch (e: Exception) {
            date
        }
    }

    private fun isSameDay(cal1: Calendar, cal2: Calendar): Boolean {
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
    }

    private fun isTomorrow(today: Calendar, other: Calendar): Boolean {
        val tomorrow = today.clone() as Calendar
        tomorrow.add(Calendar.DAY_OF_YEAR, 1)
        return isSameDay(tomorrow, other)
    }

    private fun mapSurgeryStatus(status: SurgeryStatus): OperatingRoomStatus {
        return when (status) {
            SurgeryStatus.SCHEDULED -> OperatingRoomStatus.UPCOMING
            SurgeryStatus.IN_PROGRESS -> OperatingRoomStatus.UPCOMING
            SurgeryStatus.COMPLETED -> OperatingRoomStatus.UPCOMING
            SurgeryStatus.CANCELLED -> OperatingRoomStatus.DELAYED
        }
    }

    private fun setupEditButton() {
        findViewById<ImageView>(R.id.editBtn)?.setOnClickListener {
            showEditDoctorDialog()
        }
    }

    private fun showEditDoctorDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_doctor, null)
        val etName = dialogView.findViewById<android.widget.EditText>(R.id.etDoctorName)
        val etSpecialty = dialogView.findViewById<android.widget.EditText>(R.id.etDoctorSpecialty)
        val etSubSpecialty = dialogView.findViewById<android.widget.EditText>(R.id.etDoctorSubSpecialty)

        // Pre-fill with current values (remove "Dr." prefix for editing)
        val currentName = doctorProfile.name.removePrefix("Dr. ")
        etName.setText(currentName)
        etSpecialty.setText(doctorProfile.specialty)
        etSubSpecialty.setText(doctorProfile.subSpecialty)

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Edit Doctor Information")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val newName = etName.text.toString().trim()
                val newSpecialty = etSpecialty.text.toString().trim()
                val newSubSpecialty = etSubSpecialty.text.toString().trim()

                if (newName.isEmpty() || newSpecialty.isEmpty() || newSubSpecialty.isEmpty()) {
                    Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                // Save to backend API
                saveDoctorProfile(newName, newSpecialty, newSubSpecialty)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun saveDoctorProfile(fullName: String, specialty: String, subSpecialty: String) {
        lifecycleScope.launch {
            // Parse first and last name
            val nameParts = fullName.split(" ", limit = 2)
            val firstName = nameParts.getOrNull(0) ?: fullName
            val lastName = nameParts.getOrNull(1) ?: ""

            // ALWAYS save to SharedPreferences first (guaranteed to work)
            val prefs = getSharedPreferences("DoctorProfile", MODE_PRIVATE)
            prefs.edit()
                .putString("firstName", firstName)
                .putString("lastName", lastName)
                .putString("specialty", specialty)
                .putString("subSpecialty", subSpecialty)
                .apply()

            // Update UI immediately with saved data
            doctorProfile = DoctorProfile(
                name = "Dr. $firstName $lastName",
                specialty = specialty,
                subSpecialty = subSpecialty,
                profileImageRes = doctorProfile.profileImageRes
            )
            renderDoctorDetails(doctorProfile)

            // Then try to update backend API (but don't rely on it)
            currentDoctor?.let { doctor ->
                val update = com.oros.medical.data.models.DoctorUpdate(
                    firstName = firstName,
                    lastName = lastName,
                    specialization = specialty
                )

                val result = repository.updateDoctor(doctor.id, update)

                result.onSuccess {
                    Toast.makeText(this@DoctorProfileActivity,
                        "Profile saved successfully",
                        Toast.LENGTH_SHORT).show()
                }.onFailure { error ->
                    // Still show success since we saved to SharedPreferences
                    Toast.makeText(this@DoctorProfileActivity,
                        "Profile saved locally (API: ${error.message})",
                        Toast.LENGTH_SHORT).show()
                }
            } ?: run {
                // No problem - data is already saved to SharedPreferences
                Toast.makeText(this@DoctorProfileActivity, "Profile saved successfully", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun renderDoctorDetails(profile: DoctorProfile) {
        findViewById<TextView>(R.id.doctorName).text = profile.name
        findViewById<TextView>(R.id.doctorSpecialty).text =
            getString(R.string.doctor_specialty_template, profile.specialty, profile.subSpecialty)
        findViewById<ImageView>(R.id.doctorImage).setImageResource(profile.profileImageRes)
    }

    private fun renderOperatingRooms(schedules: List<OperatingRoomSchedule>) {
        val container = findViewById<LinearLayout>(R.id.orListContainer)
        val inflater = LayoutInflater.from(this)
        container.removeAllViews()

        schedules.forEachIndexed { index, schedule ->
            val itemView = inflater.inflate(R.layout.item_or_schedule, container, false) as LinearLayout
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            if (index != 0) {
                params.topMargin = resources.getDimensionPixelSize(R.dimen.spacing_medium)
            }
            itemView.layoutParams = params

            itemView.findViewById<TextView>(R.id.orTitle).text = schedule.label
            itemView.findViewById<TextView>(R.id.orTime).text = schedule.scheduledAt

            val statusView = itemView.findViewById<TextView>(R.id.orStatus)
            statusView.text = schedule.status.displayText
            statusView.background = ContextCompat.getDrawable(this, schedule.status.backgroundRes)
            statusView.setTextColor(schedule.status.textColor)

            container.addView(itemView)
        }
    }

    private fun renderPatientNotes(notes: List<PatientNote>) {
        val container = findViewById<LinearLayout>(R.id.patientNotesContainer)
        val inflater = LayoutInflater.from(this)
        container.removeAllViews()

        notes.forEachIndexed { index, note ->
            val itemView = inflater.inflate(R.layout.item_patient_note, container, false) as LinearLayout
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            if (index != 0) {
                params.topMargin = resources.getDimensionPixelSize(R.dimen.spacing_medium)
            }
            itemView.layoutParams = params

            itemView.findViewById<TextView>(R.id.patientName).text = note.patientName
            itemView.findViewById<TextView>(R.id.patientDetails).text = note.patientDetails
            itemView.findViewById<TextView>(R.id.patientSessionSummary).text = note.todaySummary
            itemView.findViewById<TextView>(R.id.patientAssessment).text = note.assessment

            container.addView(itemView)
        }
    }

    private fun setupNavigationShortcuts() {
        // Calendar pill button (separate from footer icon)
        findViewById<TextView>(R.id.viewCalendarBtn)?.setOnClickListener {
            startActivity(Intent(this, OperatingRoomActivity::class.java))
        }
        // Footer navigation (including calendar icon) is handled by setupFooterNavigation()
    }
}

data class DoctorProfile(
    val name: String,
    val specialty: String,
    val subSpecialty: String,
    val profileImageRes: Int
)

data class OperatingRoomSchedule(
    val label: String,
    val scheduledAt: String,
    val status: OperatingRoomStatus
)

enum class OperatingRoomStatus(
    val displayText: String,
    val textColor: Int,
    val backgroundRes: Int
) {
    UPCOMING("UPCOMING", Color.parseColor("#2676FF"), R.drawable.status_upcoming),
    DELAYED("DELAYED", Color.parseColor("#E94A47"), R.drawable.status_delayed)
}

data class PatientNote(
    val patientName: String,
    val patientDetails: String,
    val todaySummary: String,
    val assessment: String
)
