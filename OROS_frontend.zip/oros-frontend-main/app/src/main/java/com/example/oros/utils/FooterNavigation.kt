package com.example.oros.utils

import android.content.Intent
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.oros.DashboardActivity
import com.example.oros.DoctorProfileActivity
import com.example.oros.OperatingRoomActivity
import com.example.oros.PatientsActivity
import com.example.oros.R
import com.oros.medical.ui.recording.RecordingActivity

/**
 * Utility extension to set up common footer navigation across all activities.
 * This ensures consistent navigation behavior when users tap footer icons.
 */
fun AppCompatActivity.setupFooterNavigation() {
    val navHome = findViewById<ImageView>(R.id.navHome)
    val navCalendar = findViewById<ImageView>(R.id.navCalendar)
    val navClipboard = findViewById<ImageView>(R.id.navClipboard)
    val navProfile = findViewById<ImageView>(R.id.navProfile)
    val navOrb = findViewById<ImageView>(R.id.navOrb)

    // Highlight current page and dim others
    updateFooterIcons(navHome, navCalendar, navClipboard, navProfile)

    // Navigate to Dashboard (Home)
    navHome?.setOnClickListener {
        if (this !is DashboardActivity) {
            startActivity(Intent(this, DashboardActivity::class.java))
        }
    }

    // Navigate to Operating Room Scheduling
    navCalendar?.setOnClickListener {
        if (this !is OperatingRoomActivity) {
            startActivity(Intent(this, OperatingRoomActivity::class.java))
        }
    }

    // Navigate to Patients List
    navClipboard?.setOnClickListener {
        if (this !is PatientsActivity) {
            startActivity(Intent(this, PatientsActivity::class.java))
        }
    }

    // Profile icon navigates to Doctor Profile
    navProfile?.setOnClickListener {
        if (this !is DoctorProfileActivity) {
            startActivity(Intent(this, DoctorProfileActivity::class.java))
        }
    }

    // Navigate to Recording (Orb button in center)
    navOrb?.setOnClickListener {
        // Show dialog to select patient or open recording
        showRecordingDialog()
    }
}

/**
 * Updates footer icons to highlight the current page and dim others
 */
private fun AppCompatActivity.updateFooterIcons(
    navHome: ImageView?,
    navCalendar: ImageView?,
    navClipboard: ImageView?,
    navProfile: ImageView?
) {
    // Define active and inactive states
    val activeAlpha = 1.0f
    val inactiveAlpha = 0.4f
    val activeScale = 1.2f
    val inactiveScale = 1.0f

    when (this) {
        is DashboardActivity -> {
            // Home is active
            navHome?.alpha = activeAlpha
            navHome?.scaleX = activeScale
            navHome?.scaleY = activeScale
            navCalendar?.alpha = inactiveAlpha
            navCalendar?.scaleX = inactiveScale
            navCalendar?.scaleY = inactiveScale
            navClipboard?.alpha = inactiveAlpha
            navClipboard?.scaleX = inactiveScale
            navClipboard?.scaleY = inactiveScale
            navProfile?.alpha = inactiveAlpha
            navProfile?.scaleX = inactiveScale
            navProfile?.scaleY = inactiveScale
        }
        is OperatingRoomActivity -> {
            // Calendar is active
            navHome?.alpha = inactiveAlpha
            navHome?.scaleX = inactiveScale
            navHome?.scaleY = inactiveScale
            navCalendar?.alpha = activeAlpha
            navCalendar?.scaleX = activeScale
            navCalendar?.scaleY = activeScale
            navClipboard?.alpha = inactiveAlpha
            navClipboard?.scaleX = inactiveScale
            navClipboard?.scaleY = inactiveScale
            navProfile?.alpha = inactiveAlpha
            navProfile?.scaleX = inactiveScale
            navProfile?.scaleY = inactiveScale
        }
        is PatientsActivity -> {
            // Clipboard is active
            navHome?.alpha = inactiveAlpha
            navHome?.scaleX = inactiveScale
            navHome?.scaleY = inactiveScale
            navCalendar?.alpha = inactiveAlpha
            navCalendar?.scaleX = inactiveScale
            navCalendar?.scaleY = inactiveScale
            navClipboard?.alpha = activeAlpha
            navClipboard?.scaleX = activeScale
            navClipboard?.scaleY = activeScale
            navProfile?.alpha = inactiveAlpha
            navProfile?.scaleX = inactiveScale
            navProfile?.scaleY = inactiveScale
        }
        is DoctorProfileActivity -> {
            // Profile is active
            navHome?.alpha = inactiveAlpha
            navHome?.scaleX = inactiveScale
            navHome?.scaleY = inactiveScale
            navCalendar?.alpha = inactiveAlpha
            navCalendar?.scaleX = inactiveScale
            navCalendar?.scaleY = inactiveScale
            navClipboard?.alpha = inactiveAlpha
            navClipboard?.scaleX = inactiveScale
            navClipboard?.scaleY = inactiveScale
            navProfile?.alpha = activeAlpha
            navProfile?.scaleX = activeScale
            navProfile?.scaleY = activeScale
        }
        else -> {
            // Default: all icons at normal state
            navHome?.alpha = inactiveAlpha
            navCalendar?.alpha = inactiveAlpha
            navClipboard?.alpha = inactiveAlpha
            navProfile?.alpha = inactiveAlpha
        }
    }
}

private fun AppCompatActivity.showRecordingDialog() {
    AlertDialog.Builder(this)
        .setTitle("Start Recording")
        .setMessage("Select a patient to record notes for, or choose a default patient.")
        .setPositiveButton("Use Default Patient") { _, _ ->
            val intent = Intent(this, RecordingActivity::class.java).apply {
                putExtra("PATIENT_ID", 1) // Default patient ID
                putExtra("PATIENT_NAME", "Default Patient")
                putExtra("FROM_DEFAULT", true) // Flag to indicate came from default
            }
            startActivity(intent)
        }
        .setNeutralButton("Select Patient") { _, _ ->
            // Navigate to patient list first
            startActivity(Intent(this, PatientsActivity::class.java))
        }
        .setNegativeButton("Cancel", null)
        .show()
}

