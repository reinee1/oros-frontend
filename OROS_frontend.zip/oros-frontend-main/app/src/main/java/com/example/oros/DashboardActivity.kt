package com.example.oros

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.oros.model.NotesTodayData
import com.example.oros.model.OrUtilizationData
import com.example.oros.model.TotalPatientsData
import com.example.oros.model.WaitTimeData
import com.example.oros.utils.setupFooterNavigation
import com.oros.medical.data.repository.OrosRepository
import kotlinx.coroutines.launch

class DashboardActivity : AppCompatActivity() {

    private lateinit var repository: OrosRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        repository = OrosRepository(this)

        // Load real data from API
        loadDashboardData()
        loadDoctorInfo()

        // Notifications header button
        findViewById<ImageView>(R.id.btnNotificationsHeader)?.setOnClickListener {
            // Navigate to notifications when implemented
            Toast.makeText(this, "Notifications coming soon", Toast.LENGTH_SHORT).show()
        }

        // Profile icon removed - no action needed

        // Setup footer navigation
        setupFooterNavigation()
    }

    private fun loadDoctorInfo() {
        lifecycleScope.launch {
            val result = repository.getCurrentDoctor()
            result.onSuccess { doctor ->
                // Doctor info loaded successfully
                // Note: tvDoctorName view doesn't exist in layout yet
                // Can add it to the layout if needed to display doctor name
            }.onFailure {
                // Silently fail - user can still use dashboard
            }
        }
    }

    private fun loadDashboardData() {
        lifecycleScope.launch {
            // Load real statistics from API
            loadNotesCount()
            loadSurgeriesCount()
            loadPatientsCount()
            loadOperatingRoomsData()
        }
    }

    private suspend fun loadNotesCount() {
        val result = repository.listNotes(limit = 100)
        result.onSuccess { notes ->
            val notesToday = NotesTodayData(
                notesCount = notes.size,
                comparisonCount = 0,
                comparisonDirection = "notes recorded"
            )
            populateNotesTodayCard(notesToday)
        }.onFailure {
            // Use fallback data
            populateNotesTodayCard(NotesTodayData(0, 0, "no data"))
        }
    }

    private suspend fun loadSurgeriesCount() {
        val result = repository.listSurgeries(limit = 100)
        result.onSuccess { surgeries ->
            val totalPatients = TotalPatientsData(
                totalCount = surgeries.size,
                message = "Total surgeries scheduled"
            )
            populateTotalPatientsCard(totalPatients)
        }.onFailure {
            populateTotalPatientsCard(TotalPatientsData(0, "No data available"))
        }
    }

    private suspend fun loadPatientsCount() {
        val result = repository.listPatients(limit = 100)
        result.onSuccess { patients ->
            // Could calculate wait time based on surgery data
            val waitTime = WaitTimeData(
                averageWaitTime = patients.size,
                comparisonTime = 0,
                comparisonDirection = "patients in system"
            )
            populateWaitTimeCard(waitTime)
        }.onFailure {
            populateWaitTimeCard(WaitTimeData(0, 0, "no data"))
        }
    }

    private suspend fun loadOperatingRoomsData() {
        val result = repository.listOperatingRooms(limit = 50)
        result.onSuccess { rooms ->
            val occupiedRooms = rooms.filter { it.status == com.oros.medical.data.models.RoomStatus.OCCUPIED }
            val utilizationPercentage = if (rooms.isNotEmpty()) {
                (occupiedRooms.size * 100) / rooms.size
            } else 0

            val orUtilization = OrUtilizationData(
                topOrLabel = if (rooms.isNotEmpty()) "OR #${rooms.first().id}" else "N/A",
                utilizationPercentage = utilizationPercentage,
                description = "utilization rate"
            )
            populateOrUtilizationCard(orUtilization)
        }.onFailure {
            populateOrUtilizationCard(OrUtilizationData("N/A", 0, "no data"))
        }
    }

    private fun populateOrUtilizationCard(data: OrUtilizationData) {
        findViewById<TextView>(R.id.tvOrUtilizationMain)?.text =
            "${data.topOrLabel} ${data.description}"
        findViewById<TextView>(R.id.tvOrUtilizationSub)?.text =
            "with a percentage of ${data.utilizationPercentage}%"
    }

    private fun populateNotesTodayCard(data: NotesTodayData) {
        findViewById<TextView>(R.id.tvNotesTodayMain)?.text =
            "You took ${data.notesCount} patient notes today!"
        findViewById<TextView>(R.id.tvNotesTodaySub)?.text =
            "That is ${data.comparisonCount} ${data.comparisonDirection} notes than yesterday"
    }

    private fun populateWaitTimeCard(data: WaitTimeData) {
        findViewById<TextView>(R.id.tvWaitTimeMain)?.text =
            "The average wait time of ORs was ${data.averageWaitTime} minutes"
        findViewById<TextView>(R.id.tvWaitTimeSub)?.text =
            "${data.comparisonDirection} than yesterday's by ${data.comparisonTime} minutes"
    }

    private fun populateTotalPatientsCard(data: TotalPatientsData) {
        findViewById<TextView>(R.id.tvTotalPatientsMain)?.text =
            "A total of ${data.totalCount} patients needed ORs today."
        findViewById<TextView>(R.id.tvTotalPatientsSub)?.text = data.message
    }
}
