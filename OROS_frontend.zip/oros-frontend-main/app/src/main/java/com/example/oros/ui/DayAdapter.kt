package com.example.oros.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.oros.R
import com.example.oros.model.DayItem

class DayAdapter(
    private var days: List<DayItem>,
    private val onDayClick: (position: Int) -> Unit
) : RecyclerView.Adapter<DayAdapter.DayViewHolder>() {

    inner class DayViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvDayName: TextView = itemView.findViewById(R.id.tvDayName)
        val tvDateNumber: TextView = itemView.findViewById(R.id.tvDateNumber)

        init {
            itemView.setOnClickListener {
                onDayClick(bindingAdapterPosition)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DayViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_day, parent, false)
        return DayViewHolder(view)
    }

    override fun onBindViewHolder(holder: DayViewHolder, position: Int) {
        val item = days[position]
        val context = holder.itemView.context
        val selectedTextColor = ContextCompat.getColor(context, R.color.card_bg)
        val unselectedTextColor = ContextCompat.getColor(context, R.color.oros_text_primary)

        holder.tvDayName.text = item.dayName
        holder.tvDateNumber.text = item.dateNumber.toString()

        if (item.isSelected) {
            holder.tvDateNumber.setBackgroundResource(R.drawable.bg_day_selected)
            holder.tvDateNumber.setTextColor(selectedTextColor)
        } else {
            holder.tvDateNumber.setBackgroundResource(R.drawable.bg_day_unselected)
            holder.tvDateNumber.setTextColor(unselectedTextColor)
        }
    }

    override fun getItemCount() = days.size

    fun submitList(newDays: List<DayItem>) {
        days = newDays
        notifyDataSetChanged()
    }
}
