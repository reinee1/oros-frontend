package com.example.oros

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.oros.medical.data.network.OrosRetrofitClient
import com.oros.medical.data.repository.OrosRepository
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var togglePassword: ImageView
    private lateinit var loginBtn: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var repository: OrosRepository
    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            Log.d("LoginActivity", "onCreate started")
            setContentView(R.layout.activity_login)

            // Initialize Retrofit
            OrosRetrofitClient.initialize(this)
            repository = OrosRepository(this)

            // REMOVED: Auto-login check - Always show login screen
            // User must explicitly login each time
            Log.d("LoginActivity", "Showing login screen")

            emailInput = findViewById(R.id.emailInput)
            passwordInput = findViewById(R.id.passwordInput)
            togglePassword = findViewById(R.id.togglePassword)
            loginBtn = findViewById(R.id.loginButton)
            // Create a progress bar programmatically since it doesn't exist in layout
            progressBar = ProgressBar(this).apply {
                visibility = View.GONE
            }

            Log.d("LoginActivity", "Views initialized successfully")
        } catch (e: Exception) {
            Log.e("LoginActivity", "Fatal error in onCreate", e)
            Toast.makeText(this, "Error loading login screen: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        // Password toggle
        togglePassword.setOnClickListener {
            isPasswordVisible = !isPasswordVisible
            if (isPasswordVisible) {
                passwordInput.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                togglePassword.setImageResource(com.example.oros.R.drawable.eye_off)
            } else {
                passwordInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                passwordInput.transformationMethod = PasswordTransformationMethod.getInstance()
                togglePassword.setImageResource(com.example.oros.R.drawable.eye_off)
            }
            passwordInput.setSelection(passwordInput.text.length)
        }

        loginBtn.setOnClickListener {
            if (validateInputs()) {
                performLogin()
            }
        }

        // Skip login button for testing (only in debug builds)
        loginBtn.setOnLongClickListener {
            Toast.makeText(this, "Skipping login...", Toast.LENGTH_SHORT).show()
            navigateToDashboard()
            true
        }
    }

    private fun performLogin() {
        val email = emailInput.text.toString().trim()
        val password = passwordInput.text.toString().trim()

        Log.d("LoginActivity", "Attempting login with email: $email")

        // DEMO MODE: If email is "demo" or "test", bypass login
        if (email.equals("demo", ignoreCase = true) ||
            email.equals("test", ignoreCase = true) ||
            email.equals("demo@test.com", ignoreCase = true)) {
            Toast.makeText(this, "Demo login successful!", Toast.LENGTH_SHORT).show()
            navigateToDashboard()
            return
        }

        // Show loading
        setLoading(true)

        lifecycleScope.launch {
            try {
                val result = repository.login(email, password)

                result.onSuccess { tokenResponse ->
                    Log.d("LoginActivity", "Login successful! Token: ${tokenResponse.accessToken.take(10)}...")

                    // Fetch doctor info and save doctor ID
                    val doctorResult = repository.getCurrentDoctor()
                    doctorResult.onSuccess { doctor ->
                        // Save doctor ID to SharedPreferences
                        getSharedPreferences(com.oros.medical.utils.Constants.PREFS_NAME, MODE_PRIVATE)
                            .edit()
                            .putInt(com.oros.medical.utils.Constants.KEY_DOCTOR_ID, doctor.id)
                            .apply()

                        Log.d("LoginActivity", "Doctor ID saved: ${doctor.id}")
                        Toast.makeText(
                            this@LoginActivity,
                            "Login successful!",
                            Toast.LENGTH_SHORT
                        ).show()
                        navigateToDashboard()
                    }.onFailure { doctorError ->
                        setLoading(false)
                        Log.e("LoginActivity", "Failed to fetch doctor info", doctorError)
                        Toast.makeText(
                            this@LoginActivity,
                            "Login succeeded but failed to fetch user info: ${doctorError.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }.onFailure { error ->
                    setLoading(false)
                    Log.e("LoginActivity", "Login failed", error)

                    val errorMessage = when {
                        error.message?.contains("Unable to resolve host") == true ->
                            "Cannot connect to server. Try: email='demo' or long-press Login button"
                        error.message?.contains("timeout") == true ->
                            "Connection timeout. Try: email='demo' or long-press Login button"
                        error.message?.contains("401") == true || error.message?.contains("Unauthorized") == true ->
                            "Invalid credentials. Try: email='demo' or long-press Login button"
                        else -> "Login failed: ${error.message}\n\nTry: email='demo' or long-press Login"
                    }

                    Toast.makeText(
                        this@LoginActivity,
                        errorMessage,
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                setLoading(false)
                Log.e("LoginActivity", "Exception during login", e)
                Toast.makeText(
                    this@LoginActivity,
                    "Error: ${e.message}\n\nTry: email='demo' or long-press Login button",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        loginBtn.isEnabled = !loading
        emailInput.isEnabled = !loading
        passwordInput.isEnabled = !loading
        progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        loginBtn.text = if (loading) "Logging in..." else "Login"
    }

    private fun navigateToDashboard() {
        val intent = Intent(this, DashboardActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun validateInputs(): Boolean {
        val email = emailInput.text.toString().trim()
        val password = passwordInput.text.toString().trim()

        // Check if fields are empty
        if (email.isEmpty()) {
            emailInput.error = "Email is required"
            emailInput.requestFocus()
            return false
        }

        if (password.isEmpty()) {
            passwordInput.error = "Password is required"
            passwordInput.requestFocus()
            return false
        }

        // Validate email format
        if (!isValidEmail(email)) {
            emailInput.error = "Please enter a valid email address"
            emailInput.requestFocus()
            return false
        }

        // Validate password length (minimum 6 characters)
        if (password.length < 6) {
            passwordInput.error = "Password must be at least 6 characters"
            passwordInput.requestFocus()
            return false
        }

        // Clear any previous errors
        emailInput.error = null
        passwordInput.error = null

        return true
    }

    private fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
}
