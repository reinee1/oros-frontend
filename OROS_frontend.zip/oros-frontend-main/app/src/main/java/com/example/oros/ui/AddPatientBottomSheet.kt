package com.example.oros.ui

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import com.example.oros.R
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class AddPatientBottomSheet : BottomSheetDialogFragment() {

    var onPatientAdded: ((name: String, age: Int, gender: String, diagnosis: String) -> Unit)? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = BottomSheetDialog(requireContext())
        val view: View = LayoutInflater.from(context)
            .inflate(R.layout.bottom_sheet_add_patient, null, false)

        val etPatientName = view.findViewById<EditText>(R.id.etPatientName)
        val etPatientAge = view.findViewById<EditText>(R.id.etPatientAge)
        val spinnerPatientGender = view.findViewById<Spinner>(R.id.spinnerPatientGender)
        val etPatientDiagnosis = view.findViewById<EditText>(R.id.etPatientDiagnosis)
        val btnConfirm = view.findViewById<Button>(R.id.btnConfirmAddPatient)

        // Setup gender spinner
        val genderOptions = arrayOf("Male", "Female")
        val genderAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, genderOptions)
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerPatientGender.adapter = genderAdapter

        btnConfirm.setOnClickListener {
            val name = etPatientName.text.toString().trim()
            val ageStr = etPatientAge.text.toString().trim()
            val gender = spinnerPatientGender.selectedItem?.toString() ?: ""
            val diagnosis = etPatientDiagnosis.text.toString().trim()

            // Validate inputs
            if (name.isEmpty()) {
                etPatientName.error = "Patient name is required"
                etPatientName.requestFocus()
                return@setOnClickListener
            }

            if (ageStr.isEmpty()) {
                etPatientAge.error = "Age is required"
                etPatientAge.requestFocus()
                return@setOnClickListener
            }

            val age = try {
                ageStr.toInt()
            } catch (e: NumberFormatException) {
                etPatientAge.error = "Please enter a valid age"
                etPatientAge.requestFocus()
                return@setOnClickListener
            }

            if (age <= 0 || age > 150) {
                etPatientAge.error = "Please enter a valid age (1-150)"
                etPatientAge.requestFocus()
                return@setOnClickListener
            }

            if (gender.isEmpty()) {
                Toast.makeText(requireContext(), "Please select a gender", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (diagnosis.isEmpty()) {
                etPatientDiagnosis.error = "Diagnosis is required"
                etPatientDiagnosis.requestFocus()
                return@setOnClickListener
            }

            // Clear errors
            etPatientName.error = null
            etPatientAge.error = null
            etPatientDiagnosis.error = null

            // Call callback
            onPatientAdded?.invoke(name, age, gender, diagnosis)
            Toast.makeText(requireContext(),
                "Patient $name added successfully", Toast.LENGTH_SHORT).show()
            dismiss()
        }

        dialog.setContentView(view)
        return dialog
    }
}

