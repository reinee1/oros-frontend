package com.example.oros.ui

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.oros.R
import com.example.oros.model.OrSlot
import com.example.oros.model.OrStatus

class OrSlotAdapter(
    private var items: List<OrSlot>,
    private val onBookNowClick: (OrSlot) -> Unit
) : RecyclerView.Adapter<OrSlotAdapter.OrSlotViewHolder>() {

    inner class OrSlotViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTimeHeader: TextView = itemView.findViewById(R.id.tvTimeHeader)
        val tvTimeRange: TextView = itemView.findViewById(R.id.tvTimeRange)
        val tvOrName: TextView = itemView.findViewById(R.id.tvOrName)
        val tvDoctor: TextView = itemView.findViewById(R.id.tvDoctor)
        val btnStatus: Button = itemView.findViewById(R.id.btnStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrSlotViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_or_slot, parent, false)
        return OrSlotViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrSlotViewHolder, position: Int) {
        val slot = items[position]
        val context = holder.itemView.context

        // Very simple header logic: for this demo assume each time appears once
        holder.tvTimeHeader.text = timeHeaderFromTime(slot.startTime)

        holder.tvTimeRange.text = slot.startTime
        holder.tvOrName.text = slot.orName

        holder.tvDoctor.text = when {
            slot.patientName != null && slot.procedure != null ->
                "${slot.patientName} • ${slot.procedure}"
            slot.patientName != null -> slot.patientName
            slot.doctorName != null && slot.procedure != null ->
                "${slot.doctorName} • ${slot.procedure}"
            slot.doctorName != null -> slot.doctorName
            else -> "Available"
        }

        holder.btnStatus.apply {
            setTextColor(ContextCompat.getColor(context, R.color.card_bg))
            setOnClickListener(null)
        }

        when (slot.status) {
            OrStatus.ONGOING -> {
                holder.btnStatus.text = "ONGOING"
                holder.btnStatus.isEnabled = false
                holder.btnStatus.backgroundTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(context, R.color.oros_status_warning)
                )
            }
            OrStatus.UPCOMING -> {
                holder.btnStatus.text = "UPCOMING"
                holder.btnStatus.isEnabled = false
                holder.btnStatus.backgroundTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(context, R.color.oros_accent_secondary)
                )
            }
            OrStatus.AVAILABLE -> {
                holder.btnStatus.text = "BOOK NOW"
                holder.btnStatus.isEnabled = true
                holder.btnStatus.backgroundTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(context, R.color.oros_accent_primary)
                )
                holder.btnStatus.setOnClickListener {
                    onBookNowClick(slot)
                }
            }
        }
    }

    override fun getItemCount() = items.size

    fun submitList(newItems: List<OrSlot>) {
        items = newItems
        notifyDataSetChanged()
    }

    private fun timeHeaderFromTime(start: String): String {
        // "12:00 PM" -> "12 PM"
        return start.substringBefore(":") + " " + start.takeLast(2)
    }
}
