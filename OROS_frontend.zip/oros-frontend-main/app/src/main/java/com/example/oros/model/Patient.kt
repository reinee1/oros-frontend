package com.example.oros

data class Patient(
    val initials: String,
    val name: String,
    val condition: String,
    val age: Int,
    val id: Int = 1 // Default to patient ID 1 if not specified
)