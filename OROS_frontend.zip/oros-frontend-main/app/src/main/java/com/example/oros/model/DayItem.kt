package com.example.oros.model

data class DayItem(
    val dayName: String,   // Mon, Tue...
    val dateNumber: Int,   // 20,21...
    val isSelected: Boolean = false
)
