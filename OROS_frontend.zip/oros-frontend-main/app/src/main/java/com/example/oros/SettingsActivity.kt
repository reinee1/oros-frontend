package com.example.oros

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.oros.utils.setupFooterNavigation
import com.oros.medical.data.repository.OrosRepository

class SettingsActivity : AppCompatActivity() {

    private lateinit var repository: OrosRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        repository = OrosRepository(this)

        // Logout button
        findViewById<Button>(R.id.logoutBtn)?.setOnClickListener {
            repository.logout()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        // Setup footer navigation
        setupFooterNavigation()
    }
}
