package com.example.oros

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PatientAdapter(
    private val patients: MutableList<Patient>,
    private val onPatientClick: ((Patient) -> Unit)? = null,
    private val onPatientDelete: ((Patient, Int) -> Unit)? = null
) : RecyclerView.Adapter<PatientAdapter.PatientViewHolder>() {

    class PatientViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val initials: TextView = itemView.findViewById(R.id.initials)
        val name: TextView = itemView.findViewById(R.id.name)
        val details: TextView = itemView.findViewById(R.id.details)
        val deleteButton: ImageView = itemView.findViewById(R.id.deletePatient)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PatientViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_patient, parent, false)
        return PatientViewHolder(view)
    }

    override fun onBindViewHolder(holder: PatientViewHolder, position: Int) {
        val patient = patients[position]
        holder.initials.text = patient.initials
        holder.name.text = patient.name
        holder.details.text = "${patient.condition}, ${patient.age}"
        
        // Set click listener on the entire item (except delete button)
        holder.itemView.setOnClickListener {
            onPatientClick?.invoke(patient)
        }

        // Delete button click listener
        holder.deleteButton.setOnClickListener {
            onPatientDelete?.invoke(patient, position)
        }
    }

    override fun getItemCount(): Int = patients.size

    fun updatePatients(newPatients: List<Patient>) {
        patients.clear()
        patients.addAll(newPatients)
        notifyDataSetChanged()
    }
}
