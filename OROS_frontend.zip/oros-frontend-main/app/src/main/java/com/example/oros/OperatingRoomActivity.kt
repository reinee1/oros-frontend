package com.example.oros

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.oros.model.DayItem
import com.example.oros.model.OrSlot
import com.example.oros.model.OrStatus
import com.example.oros.ui.BookNowBottomSheet
import com.example.oros.ui.DayAdapter
import com.example.oros.ui.OrSlotAdapter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OperatingRoomActivity : AppCompatActivity() {

    private lateinit var dayAdapter: DayAdapter
    private lateinit var slotAdapter: OrSlotAdapter
    private var dayItems: List<DayItem> = emptyList()
    private var selectedDayIndex = 0
    private val slotCatalog: MutableMap<Int, MutableList<OrSlot>> by lazy { loadSlotCatalog() }
    private val prefs: SharedPreferences by lazy {
        getSharedPreferences("operating_room_bookings", Context.MODE_PRIVATE)
    }
    private val gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_operating_room)

        setupToolbar()
        setupDayList()
        setupSlotList()
    }

    private fun setupToolbar() {
        findViewById<ImageView>(R.id.btnBack).setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
        val formatter = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
        findViewById<TextView>(R.id.tvMonth).text = formatter.format(Date())
    }

    private fun setupDayList() {
        val rvDays = findViewById<RecyclerView>(R.id.rvDays)
        dayItems = generateDayItems(selectedDayIndex)
        dayAdapter = DayAdapter(dayItems) { index ->
            selectedDayIndex = index
            dayItems = generateDayItems(selectedDayIndex)
            dayAdapter.submitList(dayItems)
            updateSlotsForSelectedDay()
        }

        rvDays.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvDays.adapter = dayAdapter
    }

    private fun setupSlotList() {
        val rvOrSlots = findViewById<RecyclerView>(R.id.rvOrSlots)
        slotAdapter = OrSlotAdapter(getSlotsForDay(selectedDayIndex)) { slot ->
            BookNowBottomSheet.newInstance(slot).apply {
                onBookingConfirmed = { slotId, patient, procedure ->
                    handleBooking(slotId, patient, procedure)
                }
            }.show(supportFragmentManager, "book_now")
        }
        rvOrSlots.layoutManager = LinearLayoutManager(this)
        rvOrSlots.adapter = slotAdapter
    }

    private fun updateSlotsForSelectedDay() {
        slotAdapter.submitList(getSlotsForDay(selectedDayIndex))
    }

    private fun generateDayItems(selectedIndex: Int): List<DayItem> {
        val names = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        val startDate = 23
        return names.mapIndexed { idx, name ->
            DayItem(
                dayName = name,
                dateNumber = startDate + idx,
                isSelected = idx == selectedIndex
            )
        }
    }

    private fun getSlotsForDay(dayIndex: Int): List<OrSlot> {
        return slotCatalog[dayIndex]?.map { it.copy() } ?: slotCatalog[0]?.map { it.copy() }.orEmpty()
    }

    private fun buildSlotCatalog(): MutableMap<Int, MutableList<OrSlot>> {
        return mutableMapOf(
            0 to mutableListOf(
                OrSlot(1, "08:00 AM", 90, "OR 1", "Dr. Alex Karev", "Appendectomy", OrStatus.ONGOING),
                OrSlot(2, "10:00 AM", 60, "OR 4", "Dr. Reem Tabet", "Knee Arthroscopy", OrStatus.UPCOMING),
                OrSlot(3, "12:00 PM", 45, "OR 2", null, null, OrStatus.AVAILABLE),
                OrSlot(4, "14:00 PM", 60, "OR 5", "Dr. Nabil Haddad", "Hernia Repair", OrStatus.UPCOMING),
                OrSlot(5, "16:00 PM", 90, "OR 3", null, null, OrStatus.AVAILABLE)
            ),
            1 to mutableListOf(
                OrSlot(6, "07:30 AM", 60, "OR 6", "Dr. Mona Issa", "Thyroidectomy", OrStatus.UPCOMING),
                OrSlot(7, "09:00 AM", 45, "OR 2", null, null, OrStatus.AVAILABLE),
                OrSlot(8, "11:15 AM", 75, "OR 4", "Dr. Karim Saad", "Hip Replacement", OrStatus.ONGOING),
                OrSlot(9, "15:00 PM", 90, "OR 1", null, null, OrStatus.AVAILABLE)
            ),
            2 to mutableListOf(
                OrSlot(10, "08:45 AM", 60, "OR 3", "Dr. Lina Farhat", "Gallbladder Removal", OrStatus.UPCOMING),
                OrSlot(11, "11:00 AM", 60, "OR 7", "Dr. Omar Barakat", "Spinal Fusion", OrStatus.UPCOMING),
                OrSlot(12, "13:30 PM", 45, "OR 2", null, null, OrStatus.AVAILABLE)
            ),
            3 to mutableListOf(
                OrSlot(13, "08:00 AM", 60, "OR 4", "Dr. Aline Majdalani", "C-section", OrStatus.ONGOING),
                OrSlot(14, "09:30 AM", 30, "OR 5", null, null, OrStatus.AVAILABLE),
                OrSlot(15, "13:00 PM", 60, "OR 6", "Dr. Rami Karam", "Robotic Prostatectomy", OrStatus.UPCOMING),
                OrSlot(16, "17:00 PM", 90, "OR 1", null, null, OrStatus.AVAILABLE)
            ),
            4 to mutableListOf(
                OrSlot(17, "07:00 AM", 120, "OR 2", "Dr. Ghassan Ward", "Open Heart Bypass", OrStatus.ONGOING),
                OrSlot(18, "10:30 AM", 60, "OR 3", null, null, OrStatus.AVAILABLE),
                OrSlot(19, "12:30 PM", 45, "OR 4", "Dr. Dana Khoury", "ENT Procedure", OrStatus.UPCOMING)
            ),
            5 to mutableListOf(
                OrSlot(20, "09:00 AM", 45, "OR 7", null, null, OrStatus.AVAILABLE),
                OrSlot(21, "10:15 AM", 60, "OR 6", "Dr. Yara Masri", "Orthopedic Fixation", OrStatus.UPCOMING),
                OrSlot(22, "14:45 PM", 75, "OR 3", "Dr. Sami Daher", "Neuro Endoscopy", OrStatus.UPCOMING)
            ),
            6 to mutableListOf(
                OrSlot(23, "08:30 AM", 60, "OR 5", "Dr. Layal Ghosn", "Cesarean Delivery", OrStatus.UPCOMING),
                OrSlot(24, "11:30 AM", 60, "OR 1", null, null, OrStatus.AVAILABLE),
                OrSlot(25, "16:00 PM", 60, "OR 2", "Dr. Tarek Semaan", "Trauma Repair", OrStatus.UPCOMING)
            )
        )
    }

    private fun handleBooking(slotId: Int, patientName: String, procedure: String) {
        val slots = slotCatalog[selectedDayIndex] ?: return
        val updated = slots.map { slot ->
            if (slot.id == slotId) {
                slot.copy(
                    patientName = patientName,
                    procedure = procedure,
                    status = OrStatus.UPCOMING
                )
            } else slot
        }
        slotCatalog[selectedDayIndex] = updated.toMutableList()
        saveSlotCatalog()
        updateSlotsForSelectedDay()
    }

    private fun loadSlotCatalog(): MutableMap<Int, MutableList<OrSlot>> {
        val savedJson = prefs.getString("slot_catalog", null)
        return if (savedJson != null) {
            try {
                val type = object : TypeToken<MutableMap<Int, MutableList<OrSlot>>>() {}.type
                gson.fromJson(savedJson, type)
            } catch (e: Exception) {
                buildSlotCatalog()
            }
        } else {
            buildSlotCatalog()
        }
    }

    private fun saveSlotCatalog() {
        val json = gson.toJson(slotCatalog)
        prefs.edit().putString("slot_catalog", json).apply()
    }
}

