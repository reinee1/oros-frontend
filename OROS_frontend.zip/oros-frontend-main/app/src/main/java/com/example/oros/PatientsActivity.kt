package com.example.oros

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.oros.ui.AddPatientBottomSheet
import com.example.oros.utils.setupFooterNavigation
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.oros.medical.ui.recording.RecordingActivity

class PatientsActivity : AppCompatActivity() {

    private val allPatients = mutableListOf<Patient>()
    private val displayedPatients = mutableListOf<Patient>()
    private lateinit var recycler: RecyclerView
    private lateinit var adapter: PatientAdapter
    private lateinit var searchInput: EditText
    private lateinit var noPatientsMessage: TextView

    private val prefs: SharedPreferences by lazy {
        getSharedPreferences("patients_data", Context.MODE_PRIVATE)
    }
    private val gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_patients)

        recycler = findViewById(R.id.patientRecycler)
        recycler.layoutManager = LinearLayoutManager(this)
        searchInput = findViewById(R.id.searchInput)
        noPatientsMessage = findViewById(R.id.noPatientsMessage)

        // Load patients from SharedPreferences
        loadPatients()
        displayedPatients.addAll(allPatients)

        // Initialize adapter with click and delete callbacks
        adapter = PatientAdapter(displayedPatients,
            onPatientClick = { patient ->
                openRecordingForPatient(patient)
            },
            onPatientDelete = { patient, _ ->
                showDeletePatientDialog(patient)
            }
        )
        recycler.adapter = adapter

        searchInput.addTextChangedListener { text ->
            filterPatients(text?.toString().orEmpty())
        }

        // Add patient button (user plus icon)
        findViewById<ImageView>(R.id.userPlus)?.setOnClickListener {
            showAddPatientBottomSheet()
        }

        filterPatients("")
        
        setupFooterNavigation()
    }

    private fun showAddPatientBottomSheet() {
        val bottomSheet = AddPatientBottomSheet()
        bottomSheet.onPatientAdded = { name, age, gender, diagnosis ->
            // Generate initials from name
            val initials = name.split(" ").mapNotNull { it.firstOrNull()?.toString() }
                .take(2).joinToString("").uppercase()

            // Create new patient with ID=1 (default patient ID from database)
            val newPatient = Patient(initials, name, diagnosis, age, id = 1)
            allPatients.add(0, newPatient)
            savePatients()
            filterPatients(searchInput.text.toString())
        }
        bottomSheet.show(supportFragmentManager, "AddPatientBottomSheet")
    }

    private fun showDeletePatientDialog(patient: Patient) {
        AlertDialog.Builder(this)
            .setTitle("Delete Patient")
            .setMessage("Are you sure you want to delete ${patient.name}? This action cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                allPatients.remove(patient)
                savePatients()
                filterPatients(searchInput.text.toString())
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openRecordingForPatient(patient: Patient) {
        val intent = Intent(this, RecordingActivity::class.java).apply {
            putExtra("PATIENT_ID", patient.id)
            putExtra("PATIENT_NAME", patient.name)
            putExtra("FROM_PATIENT_LIST", true) // Flag to indicate came from patient list
        }
        startActivity(intent)
    }

    private fun filterPatients(query: String) {
        val trimmedQuery = query.trim()
        val filtered = if (trimmedQuery.isEmpty()) {
            allPatients
        } else {
            allPatients.filter {
                it.name.contains(trimmedQuery, ignoreCase = true) ||
                        it.condition.contains(trimmedQuery, ignoreCase = true)
            }
        }

        adapter.updatePatients(filtered)

        if (filtered.isEmpty()) {
            recycler.visibility = View.GONE
            noPatientsMessage.visibility = View.VISIBLE
        } else {
            recycler.visibility = View.VISIBLE
            noPatientsMessage.visibility = View.GONE
        }
    }

    private fun loadPatients() {
        val savedJson = prefs.getString("patients_list", null)
        if (savedJson != null) {
            try {
                val type = object : TypeToken<MutableList<Patient>>() {}.type
                val loadedPatients: MutableList<Patient> = gson.fromJson(savedJson, type)
                allPatients.addAll(loadedPatients)
            } catch (e: Exception) {
                // If loading fails, use default patients
                loadDefaultPatients()
            }
        } else {
            // First time, load default patients
            loadDefaultPatients()
        }
    }

    private fun loadDefaultPatients() {
        allPatients.addAll(
            listOf(
                Patient("DP", "Default Patient", "General", 25, id = 1),
                Patient("PT", "Pat Test", "General", 25, id = 2),
                Patient("S1", "String Test 1", "General", 25, id = 3),
                Patient("S2", "String Test 2", "General", 25, id = 4),
                Patient("S3", "String Test 3", "General", 25, id = 5)
            )
        )
        savePatients()
    }

    private fun savePatients() {
        val json = gson.toJson(allPatients)
        prefs.edit().putString("patients_list", json).apply()
    }
}