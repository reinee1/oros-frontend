package com.example.oros.ui

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.oros.R
import com.example.oros.model.OrSlot
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class BookNowBottomSheet : BottomSheetDialogFragment() {

    companion object {
        private const val ARG_SLOT_ID = "arg_slot_id"
        private const val ARG_OR_NAME = "arg_or_name"
        private const val ARG_TIME = "arg_time"

        fun newInstance(slot: OrSlot): BookNowBottomSheet {
            val f = BookNowBottomSheet()
            val args = Bundle()
            args.putInt(ARG_SLOT_ID, slot.id)
            args.putString(ARG_OR_NAME, slot.orName)
            args.putString(ARG_TIME, slot.startTime)
            f.arguments = args
            return f
        }
    }

    var onBookingConfirmed: ((slotId: Int, patientName: String, procedure: String) -> Unit)? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = BottomSheetDialog(requireContext())
        val view: View = LayoutInflater.from(context)
            .inflate(R.layout.bottom_sheet_book_now, null, false)

        val slotId = arguments?.getInt(ARG_SLOT_ID) ?: -1
        val orName = arguments?.getString(ARG_OR_NAME) ?: ""
        val time = arguments?.getString(ARG_TIME) ?: ""

        val tvDetails = view.findViewById<TextView>(R.id.tvBookingDetails)
        tvDetails.text = "$orName\n$time"

        val etPatient = view.findViewById<EditText>(R.id.etPatientName)
        val etProcedure = view.findViewById<EditText>(R.id.etProcedure)
        val btnConfirm = view.findViewById<Button>(R.id.btnConfirmBooking)

        btnConfirm.setOnClickListener {
            val name = etPatient.text.toString().trim()
            val proc = etProcedure.text.toString().trim()

            if (name.isEmpty() || proc.isEmpty()) {
                Toast.makeText(requireContext(),
                    "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else {
                onBookingConfirmed?.invoke(slotId, name, proc)
                Toast.makeText(requireContext(),
                    "Booked $orName at $time for $name", Toast.LENGTH_LONG).show()
                dismiss()
            }
        }

        dialog.setContentView(view)
        return dialog
    }
}
