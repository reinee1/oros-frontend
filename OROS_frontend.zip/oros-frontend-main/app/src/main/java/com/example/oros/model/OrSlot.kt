package com.example.oros.model

enum class OrStatus {
    ONGOING, UPCOMING, AVAILABLE
}

data class OrSlot(
    val id: Int,
    val startTime: String,   // "12:00 PM"
    val durationMinutes: Int?,
    val orName: String,      // "OR 4"
    val doctorName: String?, // null if just "Available"
    val procedure: String?,  // null if none
    val status: OrStatus,
    val patientName: String? = null
)
