package com.example.oros.model

/**
 * Data models for dashboard cards.
 * These will be replaced with database models when backend is connected.
 */
data class OrUtilizationData(
    val topOrLabel: String,        // e.g., "OR #1"
    val utilizationPercentage: Int, // e.g., 82
    val description: String         // e.g., "had the most utilization today"
)

data class NotesTodayData(
    val notesCount: Int,           // e.g., 37
    val comparisonCount: Int,       // e.g., 12
    val comparisonDirection: String // e.g., "more" or "less"
)

data class WaitTimeData(
    val averageWaitTime: Int,       // in minutes, e.g., 17
    val comparisonTime: Int,        // difference in minutes, e.g., 3
    val comparisonDirection: String // e.g., "less" or "more"
)

data class TotalPatientsData(
    val totalCount: Int,           // e.g., 24
    val message: String             // e.g., "Incredible progress!"
)


