# OROS Login Setup Guide

## ✅ BUILD SUCCESSFUL - Ready to Run!

The app has been built successfully. Here's everything you need to know about login.

---

## 🚀 Quick Start

### Option 1: Skip Login (For Testing)
**Long-press the Login button** to skip authentication and go directly to the dashboard.

### Option 2: Use Real Login
You need a running backend server. See backend setup below.

---

## 🔧 Backend Server Setup

### Current Configuration
The app is configured to connect to:
- **Emulator**: `http://10.0.2.2:8000/`
- **Physical Device**: You need to update the URL (see below)

### Location of API URL
File: `app/src/main/java/com/oros/medical/utils/Constants.kt` (Line 12)

### Change Backend URL

#### For Android Emulator:
```kotlin
const val BASE_URL = "http://192.168.10.163:8000/"  // ✅ Current setting
```

#### For Physical Android Device:
1. Find your computer's IP address:
   - Windows: Open CMD and run `ipconfig`, look for IPv4 Address
   - Mac/Linux: Run `ifconfig` or `ip addr`

2. Update Constants.kt:
```kotlin
const val BASE_URL = "http://YOUR_IP_ADDRESS:8000/"  // e.g., http://192.168.1.100:8000/
```

3. Rebuild the app:
```bash
cd oros-frontend-main
./gradlew assembleDebug -x lint
```

#### For Production Server:
```kotlin
const val BASE_URL = "https://your-production-server.com/"
```

---

## 🔐 Login API Details

### Endpoint
```
POST /auth/login
Content-Type: application/x-www-form-urlencoded
```

### Request Body
```
username: email@example.com
password: yourpassword
```

### Expected Response
```json
{
  "access_token": "your-jwt-token",
  "token_type": "bearer"
}
```

### Test Credentials
Ask your backend developer for test credentials, or check your backend's user creation scripts.

---

## 🐛 Troubleshooting

### Error: "Cannot connect to server"
**Cause**: Backend is not running or URL is incorrect

**Solutions**:
1. **Start your backend server** on port 8000
2. Verify the backend is running:
   ```bash
   curl http://localhost:8000/docs
   # or visit in browser: http://localhost:8000/docs
   ```
3. Check if BASE_URL matches your setup:
   - Emulator: Use `10.0.2.2` (NOT `localhost`)
   - Physical device: Use computer's IP address

### Error: "Invalid email or password"
**Cause**: Wrong credentials or user doesn't exist

**Solutions**:
1. Create a user in your backend
2. Verify credentials are correct
3. Check backend logs for authentication errors

### Error: "Connection timeout"
**Cause**: Network issue or firewall blocking connection

**Solutions**:
1. Disable firewall temporarily to test
2. Ensure phone and computer are on same WiFi network (for physical device)
3. Check if backend is listening on `0.0.0.0:8000` (not just `127.0.0.1:8000`)

---

## 📱 Running the App

### In Android Studio:
1. Open project in Android Studio
2. Click the green Run button (▶️)
3. Select your device/emulator
4. App will install and launch

### Via Command Line:
```bash
# Install on connected device
adb install app/build/outputs/apk/debug/app-debug.apk

# Or if multiple devices
adb -s DEVICE_ID install app/build/outputs/apk/debug/app-debug.apk
```

### Check Logs:
```bash
# View app logs in real-time
adb logcat | grep LoginActivity
```

---

## 🔍 Login Flow

1. **App starts** → LoginActivity loads
2. **User enters email/password** → Validates format
3. **Clicks Login** → Shows loading state
4. **API call** → POST to `/auth/login`
5. **Success** → Saves token → Navigates to Dashboard
6. **Failure** → Shows error message → Stays on login screen

---

## 💡 Tips

### For Development:
- **Long-press Login button** to skip authentication
- Check logs with: `adb logcat | grep "LoginActivity"`
- Error messages are detailed and tell you what went wrong

### Network Security:
- App allows HTTP connections (cleartext traffic enabled)
- This is for development only
- For production, use HTTPS

### Session Management:
- Token is saved in SharedPreferences
- App checks if logged in on startup
- Logout clears the token

---

## 📝 Summary of Changes Made

### ✅ Fixed Issues:
1. **View binding errors** - Removed references to non-existent views
2. **Toast context error** - Fixed context reference in DoctorProfileActivity
3. **Gradle sync** - Updated AGP version and fixed configuration
4. **Build errors** - All compilation errors resolved

### ✅ Improvements:
1. **Better error messages** - Specific feedback for different errors
2. **Logging** - Detailed logs for debugging
3. **Skip login option** - Long-press for testing without backend
4. **Network config** - Cleartext traffic enabled for development

---

## 🎯 Next Steps

1. **Start your backend server** (if you have one)
2. **Update BASE_URL** if using physical device
3. **Rebuild app** if you changed constants
4. **Run and test** - Try both real login and skip login

---

## ❓ Need Help?

If login still doesn't work:
1. Check the logcat output: `adb logcat | grep "LoginActivity"`
2. Verify backend is running: `curl http://localhost:8000/docs`
3. Ensure backend endpoint is `/auth/login` (not `/login`)
4. Check that backend expects form-urlencoded (not JSON)

---

**Generated**: 2025-11-21
**App Version**: Debug Build
**Status**: ✅ READY TO RUN
